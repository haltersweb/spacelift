/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FBFAF5',
          100: '#F5F2E6',
          200: '#EDE7D5',
          300: '#E0D9C6',
          400: '#D4CCB7',
          500: '#C7BDA4',
          600: '#A89F8A',
          700: '#7A7363',
          800: '#5C5648',
          900: '#3D3930',
        },
        lavender: {
          50: '#F5F2FA',
          100: '#E4DEF2',
          200: '#D1C8E8',
          300: '#BDB6C9',
          400: '#A29BB8',
          500: '#8A839F',
          600: '#6F6A82',
          700: '#56525F',
          800: '#3D3A45',
          900: '#2B2735',
        },
        sage: {
          50: '#EFF2E8',
          100: '#E2EBD4',
          200: '#C9D8B6',
          300: '#B4C69E',
          400: '#9AB583',
          500: '#7E9B66',
          600: '#688052',
          700: '#4A6634',
          800: '#3A4F28',
          900: '#2F3A28',
        },
        plum: {
          DEFAULT: '#2B2735',
          light: '#3D3749',
          lighter: '#5F5A6B',
          dark: '#1C1924',
        },
        accent: {
          warm: '#E09A1F',
          coral: '#E8634A',
          rose: '#D9A7AF',
          gold: '#E3BD55',
          blush: '#F1C3CA',
        },
        success: {
          DEFAULT: '#1D7342',
          light: '#E2F2E7',
          bg: '#EDF2E4',
        },
        warning: {
          DEFAULT: '#E09A1F',
          light: '#FFEFCF',
          bg: '#FBF3DD',
        },
        error: {
          DEFAULT: '#B32F1A',
          light: '#FCE3DD',
          bg: '#FBEFF0',
        },
        info: {
          DEFAULT: '#6F8BA3',
          light: '#EAF0F4',
        },
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'Figtree', 'system-ui', 'sans-serif'],
        body: ['Figtree', 'system-ui', 'sans-serif'],
        sans: ['Figtree', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      borderRadius: {
        'xl': '12px',
        '2xl': '16px',
        '3xl': '20px',
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
      },
      maxWidth: {
        'workspace': '1440px',
      },
      boxShadow: {
        'soft': '0 2px 8px rgba(43, 39, 53, 0.08)',
        'card': '0 4px 16px rgba(43, 39, 53, 0.10)',
        'elevated': '0 8px 32px rgba(43, 39, 53, 0.14)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
        'slide-up': 'slideUp 0.35s cubic-bezier(0.16, 1, 0.3, 1)',
        'slide-right': 'slideRight 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
        'pulse-soft': 'pulseSoft 2s ease-in-out infinite',
        'shimmer': 'shimmer 1.5s linear infinite',
        'pin-bounce': 'pinBounce 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
        'glow-pulse': 'glowPulse 2.5s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideRight: {
          '0%': { opacity: '0', transform: 'translateX(-12px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        pulseSoft: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.6' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        pinBounce: {
          '0%': { transform: 'scale(0)', opacity: '0' },
          '60%': { transform: 'scale(1.15)', opacity: '1' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        glowPulse: {
          '0%, 100%': { filter: 'brightness(1)' },
          '50%': { filter: 'brightness(1.15)' },
        },
      },
      transitionTimingFunction: {
        'smooth': 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
    },
  },
  plugins: [],
};
