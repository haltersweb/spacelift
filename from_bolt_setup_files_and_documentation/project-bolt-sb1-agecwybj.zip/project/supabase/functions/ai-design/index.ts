import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface DesignRequest {
  project_id: string;
  user_message: string;
  project_context: {
    title: string;
    room_type: string;
    occasion: string | null;
    budget_cents: number;
    budget_cap: string;
    wall_width_ft: number | null;
    damage_level: string;
    mood: string | null;
    lighting_recipe: { ambient: number; task: number; accent: number } | null;
  };
  current_items: Array<{
    pin_number: number;
    name: string;
    store: string;
    price_cents: number;
    quantity: number;
    category: string;
    damage_badge: string;
  }>;
  history: Array<{ role: string; content: string }>;
}

interface DesignResponse {
  message: string;
  action: {
    type: "swap" | "redesign" | "fit-to-budget" | "view" | "info" | "add-item" | "remove-item";
    pin?: number;
    property?: string;
    value?: string;
    name?: string;
    price?: number;
    store?: string;
    wire_color?: string;
    mood?: string;
    view?: string;
    items?: Array<{
      name: string;
      store: string;
      price_cents: number;
      category: string;
      damage_badge: string;
    }>;
  } | null;
  new_items?: Array<{
    name: string;
    store: string;
    price_cents: number;
    quantity: number;
    category: string;
    damage_badge: string;
    wire_color?: string;
  }>;
}

interface ImageDesignRequest {
  mode: "generate-design";
  project_id: string;
  photo_url: string;
  version_id: string;
  room_type: string;
  occasion: string | null;
  budget_cents: number;
  mood: string | null;
  damage_level: string;
  lighting_recipe: { ambient: number; task: number; accent: number } | null;
  wall_width_ft: number | null;
  user_message?: string;
}

interface LightingPreviewRequest {
  mode: "generate-lighting-preview";
  photo_url: string;
  room_type: string;
  mood: string;
  lighting_recipe: { ambient: number; task: number; accent: number };
  damage_level: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const anonClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await anonClient.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid or expired session" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // Route: generate-lighting-preview (preview room at evening with mood lighting)
    if (body.mode === "generate-lighting-preview") {
      const lpReq = body as LightingPreviewRequest;

      const openaiKey = Deno.env.get("OPENAI_API_KEY");
      let previewUrl: string | null = null;

      if (openaiKey) {
        previewUrl = await generateLightingPreviewImage(lpReq, openaiKey, user.id, supabaseUrl, supabaseServiceKey);
      } else {
        previewUrl = lpReq.photo_url || null;
      }

      return new Response(
        JSON.stringify({
          preview_url: previewUrl,
          message: "Lighting preview generated successfully",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Route: generate-design (image generation)
    if (body.mode === "generate-design") {
      const imgReq = body as ImageDesignRequest;

      // Verify project ownership
      const { data: project, error: projError } = await adminClient
        .from("projects")
        .select("user_id, photo_url")
        .eq("id", imgReq.project_id)
        .maybeSingle();

      if (projError || !project) {
        return new Response(
          JSON.stringify({ error: "Project not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (project.user_id !== user.id) {
        return new Response(
          JSON.stringify({ error: "Access denied" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const openaiKey = Deno.env.get("OPENAI_API_KEY");
      let designImageUrl: string | null = null;

      if (openaiKey) {
        designImageUrl = await generateDesignImage(imgReq, project.photo_url, openaiKey, user.id, supabaseUrl, supabaseServiceKey);
      } else {
        // No API key — generate a styled placeholder image using the user's photo with a CSS-like filter description
        designImageUrl = await generatePlaceholderImage(imgReq, user.id, supabaseUrl, supabaseServiceKey);
      }

      // Save the image URL to the design version
      if (designImageUrl && imgReq.version_id) {
        await adminClient
          .from("design_versions")
          .update({ design_image_url: designImageUrl })
          .eq("id", imgReq.version_id);
      }

      return new Response(
        JSON.stringify({
          design_image_url: designImageUrl,
          message: "Design image generated successfully",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Default route: chat / design recommendations
    const chatBody = body as DesignRequest;

    // Verify project ownership
    const { data: project, error: projError } = await adminClient
      .from("projects")
      .select("user_id")
      .eq("id", chatBody.project_id)
      .maybeSingle();

    if (projError || !project) {
      return new Response(
        JSON.stringify({ error: "Project not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    if (project.user_id !== user.id) {
      return new Response(
        JSON.stringify({ error: "Access denied" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiApiKey = Deno.env.get("OPENAI_API_KEY") || Deno.env.get("ANTHROPIC_API_KEY");

    if (aiApiKey) {
      const response = await callAI(chatBody, aiApiKey);
      return new Response(
        JSON.stringify(response),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const fallback = generateFallbackResponse(chatBody);
    return new Response(
      JSON.stringify(fallback),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

// ---- Image Generation ----

async function generateDesignImage(
  req: ImageDesignRequest,
  projectPhotoUrl: string | null,
  apiKey: string,
  userId: string,
  supabaseUrl: string,
  supabaseServiceKey: string
): Promise<string | null> {
  let roomAnalysis = "";

  // Step 1: If we have a photo, analyze it with GPT-4o vision
  if (projectPhotoUrl) {
    try {
      roomAnalysis = await analyzeRoomPhoto(projectPhotoUrl, apiKey);
    } catch {
      // If vision analysis fails, proceed without it
    }
  }

  // Step 2: Build a detailed prompt combining room analysis + design settings
  const prompt = buildDesignPrompt(req, roomAnalysis);

  // Step 3: Generate the image and get raw bytes directly
  const imageBytes = await generateDalleImage(prompt, apiKey);

  // Step 4: Upload to Supabase storage
  return await uploadToStorage(imageBytes, `${userId}/${Date.now()}-design.png`, supabaseUrl, supabaseServiceKey);
}

async function analyzeRoomPhoto(photoUrl: string, apiKey: string): Promise<string> {
  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "You are an interior design assistant. Analyze this room photo and describe it in detail for use in generating a redesigned version. Describe: room type, wall colors, floor type, existing furniture and its placement, windows and natural light sources, ceiling height (estimate), wall width (estimate), current lighting fixtures, and any notable architectural features. Keep it under 150 words, focus on physical space details that would matter for redecorating.",
            },
            {
              type: "image_url",
              image_url: { url: photoUrl },
            },
          ],
        },
      ],
      max_tokens: 300,
      temperature: 0.3,
    }),
  });

  if (!resp.ok) {
    throw new Error(`Vision analysis failed: ${resp.status}`);
  }

  const data = await resp.json();
  const content = data.choices?.[0]?.message?.content;
  return content || "";
}

function buildDesignPrompt(req: ImageDesignRequest, roomAnalysis: string): string {
  const moodDesc: Record<string, string> = {
    "Cozy": "warm pools of light from lamps and candles, low overhead lighting, warm color tones, soft textures, intimate atmosphere",
    "Festive": "string lights and colorful decorations, sparkle and glow, vibrant energy, celebratory atmosphere, layered lighting",
    "Sleek": "clean modern lines, even recessed lighting, minimal decor, cool color palette, polished surfaces",
    "Minimalist": "functional lighting only, sparse decor, clean surfaces, neutral tones, uncluttered",
    "Romantic": "soft dim candlelight, warm bulbs, gentle shadows, intimate atmosphere, plush textures, rose tones",
    "Bright": "high ambient daylight, cool temperature lighting, airy and open feel, light-colored surfaces",
  };

  const moodText = moodDesc[req.mood ?? "Cozy"] ?? moodDesc["Cozy"];
  const lighting = req.lighting_recipe;
  const lightingDesc = lighting
    ? `${lighting.ambient}% ambient overhead fill light, ${lighting.task}% task lighting for specific areas, ${lighting.accent}% accent decorative lighting from string lights and lamps`
    : "balanced lighting throughout";

  const damageDesc = req.damage_level === "none"
    ? "no wall damage — decor must use command strips and freestanding items only, no nails or wall mounting"
    : req.damage_level === "minor"
      ? "minor wall damage acceptable — small nails and command strips allowed for hanging decor"
      : "anything goes — wall mounting, nails, hooks, and permanent fixtures are all acceptable";

  const occasionText = req.occasion && req.occasion !== "Everyday"
    ? ` The space is being prepared for ${req.occasion.toLowerCase()}.`
    : "";

  const analysisText = roomAnalysis
    ? `\n\nThe room to redesign has these characteristics:\n${roomAnalysis}\n\nRedesign THIS specific room — keep the same basic layout, wall positions, windows, and architectural features, but transform the decor, lighting, and furnishings to match the requested mood and style.`
    : "";

  return `Photorealistic interior design photograph of a ${req.room_type.toLowerCase()} redesigned for ${req.occasion?.toLowerCase() ?? "everyday"} use.${occasionText}
Mood and atmosphere: ${moodText}.
Lighting setup: ${lightingDesc}.
Installation constraints: ${damageDesc}.
Budget level: ${(req.budget_cents / 100).toFixed(0)} total — furnishings should look affordable and rental-friendly, not luxury.
Room dimensions: approximately ${req.wall_width_ft ?? 12} feet wide.${analysisText}

Style: photorealistic wide-angle photograph taken from a corner showing the full room. The design should look like a real, lived-in rental apartment — not a staged showroom. Include practical items like string lights, area rugs, wall art, plants, and furniture that fit the budget and mood. The lighting should clearly reflect the requested mood — warm and dim for cozy, sparkling for festive, clean and bright for sleek, etc.`;
}

async function generateLightingPreviewImage(
  req: LightingPreviewRequest,
  apiKey: string,
  userId: string,
  supabaseUrl: string,
  supabaseServiceKey: string
): Promise<string | null> {
  let roomAnalysis = "";

  if (req.photo_url) {
    try {
      roomAnalysis = await analyzeRoomPhoto(req.photo_url, apiKey);
    } catch {
      // proceed without analysis
    }
  }

  const moodDesc: Record<string, string> = {
    "Cozy": "warm pools of golden light from table lamps and candle lanterns, low overhead light, warm amber glow, soft shadows",
    "Festive": "string lights draped across the wall, colorful paper lanterns glowing, warm celebratory sparkle, layered festive glow",
    "Sleek": "even cool-white recessed lighting, clean modern floor lamp with bright white beam, polished surfaces reflecting light",
    "Minimalist": "single functional floor lamp with clean white light, sparse illumination, mostly dark with one bright area",
    "Romantic": "dim candlelight on tables, warm rose-tinted bulb glow, soft pink shadows, intimate low lighting",
    "Bright": "high ambient daylight from windows, cool bright overhead light, airy and well-lit, no shadows",
  };

  const moodText = moodDesc[req.mood] ?? moodDesc["Cozy"];
  const lr = req.lighting_recipe;
  const lightingDesc = `${lr.ambient}% ambient overhead fill, ${lr.task}% task lighting from floor/desk lamps, ${lr.accent}% accent decorative lighting from string lights and lanterns`;

  const damageDesc = req.damage_level === "none"
    ? "no wall damage — lights hung with command strips or freestanding only"
    : req.damage_level === "minor"
      ? "small nails allowed for hanging string lights"
      : "wall mounting and hooks allowed for lighting fixtures";

  const analysisText = roomAnalysis
    ? `\n\nThe room has these characteristics:\n${roomAnalysis}\n\nKeep the same room layout, furniture, walls, and windows — only change the lighting and add lighting fixtures to create the mood. Do NOT rearrange furniture or add new furniture.`
    : "";

  const prompt = `Photorealistic interior photograph of a ${req.room_type.toLowerCase()} at EVENING (after sunset, dark outside windows) with ${req.mood.toLowerCase()} lighting mood.
Lighting setup: ${lightingDesc}.
Atmosphere: ${moodText}.
Installation constraints: ${damageDesc}.${analysisText}

The image MUST show: evening/nighttime scene (dark or no daylight from windows), the specific lighting fixtures described (string lights, lanterns, lamps, candles — whatever matches the mood), and the room transformed ONLY by lighting — same furniture, same layout, same walls. The lighting should be the dominant visual element. Warm tones for cozy/festive/romantic, cool tones for sleek/minimalist/bright.

Style: photorealistic wide-angle photograph from a corner showing the full room. Real rental apartment, not a showroom.`;

  const imageBytes = await generateDalleImage(prompt, apiKey);
  return await uploadToStorage(imageBytes, `${userId}/${Date.now()}-lighting-preview.png`, supabaseUrl, supabaseServiceKey);
}

async function generateDalleImage(prompt: string, apiKey: string): Promise<Uint8Array> {
  const genResp = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-image-1",
      prompt,
      n: 1,
      size: "1536x1024",
      quality: "high",
    }),
  });

  if (!genResp.ok) {
    const errText = await genResp.text();
    throw new Error(`Image generation failed: ${errText}`);
  }

  const genData = await genResp.json();

  // gpt-image-1 returns base64 by default; fall back to URL if present
  const b64 = genData.data?.[0]?.b64_json;
  if (b64) {
    return Uint8Array.from(atob(b64), c => c.charCodeAt(0));
  }

  const url = genData.data?.[0]?.url;
  if (url) {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`Failed to download image: ${resp.status}`);
    const buf = await resp.arrayBuffer();
    return new Uint8Array(buf);
  }

  throw new Error("No image in generation response");
}

async function uploadToStorage(
  imageBytes: Uint8Array,
  fileName: string,
  supabaseUrl: string,
  supabaseServiceKey: string
): Promise<string> {
  const adminClient = createClient(supabaseUrl, supabaseServiceKey);
  const { error: uploadError } = await adminClient
    .storage
    .from("design-images")
    .upload(fileName, imageBytes, {
      contentType: "image/png",
      upsert: false,
    });

  if (uploadError) throw new Error(`Upload failed: ${uploadError.message}`);

  const { data: urlData } = adminClient
    .storage
    .from("design-images")
    .getPublicUrl(fileName);

  return urlData.publicUrl;
}

async function generatePlaceholderImage(
  req: ImageDesignRequest,
  userId: string,
  supabaseUrl: string,
  supabaseServiceKey: string
): Promise<string | null> {
  // When no AI key is configured, we can't generate a real AI image.
  // Return the user's original photo URL so the UI shows it, and mark it as "pending AI."
  // The frontend will show a notice that AI image generation needs an API key.
  const adminClient = createClient(supabaseUrl, supabaseServiceKey);
  const { data: project } = await adminClient
    .from("projects")
    .select("photo_url")
    .eq("id", req.project_id)
    .maybeSingle();

  return project?.photo_url ?? null;
}

// ---- Chat AI ----

async function callAI(body: DesignRequest, apiKey: string): Promise<DesignResponse> {
  const useOpenAI = !!Deno.env.get("OPENAI_API_KEY");

  const systemPrompt = `You are SpaceLift, an AI assistant that helps renters design their rental space within budget and lease constraints.

You understand:
- Budget limits (hard cap, soft cap, or no limit)
- Lease damage rules (no damage, minor OK, anything goes)
- Lighting moods (Cozy, Festive, Sleek, Minimalist, Romantic, Bright)
- Real products from real stores with real prices

When a user asks for a change, respond with:
1. A natural language message explaining what you did
2. An action object describing the change programmatically

Action types:
- "swap": Change a specific item (pin number, property, value, name, price, store, wire_color)
- "redesign": Change the overall mood/design — triggers a new AI image generation
- "fit-to-budget": Suggest cheaper alternatives to fit within budget
- "view": Change the room view (day/evening)
- "info": Just provide information, no changes
- "add-item": Add a new item to the shopping list
- "remove-item": Remove an item from the list

Always keep items within the user's damage level and budget constraints.
Format prices in cents (e.g., $10.00 = 1000).
Categories: Lighting, Decor, Textiles, Tableware, Furniture
Damage badges: no-damage, minor, needs-ok

Respond in JSON format: { "message": "...", "action": { "type": "...", ... } }`;

  const userContext = `Project: ${body.project_context.title}
Room: ${body.project_context.room_type}
Occasion: ${body.project_context.occasion || "Everyday"}
Budget: $${(body.project_context.budget_cents / 100).toFixed(2)} (${body.project_context.budget_cap})
Wall width: ${body.project_context.wall_width_ft} ft
Damage level: ${body.project_context.damage_level}
Mood: ${body.project_context.mood}
Lighting: ambient ${body.project_context.lighting_recipe?.ambient}%, task ${body.project_context.lighting_recipe?.task}%, accent ${body.project_context.lighting_recipe?.accent}%

Current items:
${body.current_items.map(i => `  Pin ${i.pin_number}: ${i.name} - ${i.store} - $${(i.price_cents / 100).toFixed(2)} x${i.quantity} [${i.damage_badge}]`).join("\n")}

User message: ${body.user_message}`;

  const messages = [
    { role: "system", content: systemPrompt },
    ...body.history.slice(-10).map(h => ({
      role: h.role === "assistant" ? "assistant" : "user",
      content: h.content,
    })),
    { role: "user", content: userContext },
  ];

  if (useOpenAI) {
    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages,
        response_format: { type: "json_object" },
        max_tokens: 800,
        temperature: 0.7,
      }),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      throw new Error(`OpenAI API error: ${errText}`);
    }

    const data = await resp.json();
    const content = data.choices?.[0]?.message?.content;
    if (!content) throw new Error("Empty AI response");

    try {
      return JSON.parse(content) as DesignResponse;
    } catch {
      return { message: content, action: { type: "info" } };
    }
  } else {
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-5-sonnet-20241022",
        system: systemPrompt,
        messages: messages.map(m => ({
          role: m.role === "system" ? "user" : m.role,
          content: m.content,
        })),
        max_tokens: 800,
      }),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      throw new Error(`Anthropic API error: ${errText}`);
    }

    const data = await resp.json();
    const content = data.content?.[0]?.text;
    if (!content) throw new Error("Empty AI response");

    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]) as DesignResponse;
      }
      return { message: content, action: { type: "info" } };
    } catch {
      return { message: content, action: { type: "info" } };
    }
  }
}

function generateFallbackResponse(body: DesignRequest): DesignResponse {
  const msg = body.user_message.toLowerCase();
  const ctx = body.project_context;
  const totalCents = body.current_items.reduce((s, i) => s + i.price_cents * i.quantity, 0);
  const budgetCents = ctx.budget_cents;

  if (msg.includes("black wire") || msg.includes("black cord")) {
    const lightItem = body.current_items.find(i => i.name.toLowerCase().includes("string light") || i.name.toLowerCase().includes("light"));
    if (lightItem) {
      return {
        message: `Swapped to black-wire ${lightItem.name.toLowerCase()}, same price. Pin ${lightItem.pin_number} updated.`,
        action: { type: "swap", pin: lightItem.pin_number, property: "wire_color", value: "black" },
      };
    }
  }

  if (msg.includes("light up") || msg.includes("glow") || msg.includes("led")) {
    const lanternItem = body.current_items.find(i => i.name.toLowerCase().includes("lantern"));
    if (lanternItem) {
      const newPrice = 1499;
      const over = totalCents - newPrice + lanternItem.price_cents > budgetCents && budgetCents > 0;
      return {
        message: over
          ? `Swapped to LED lanterns — they glow! That puts you $${(((totalCents - lanternItem.price_cents + newPrice) - budgetCents) / 100).toFixed(2)} over your $${(budgetCents / 100).toFixed(0)} cap. Would you like me to find a cheaper alternative?`
          : `Swapped to LED lanterns — they glow! Still within budget.`,
        action: { type: "swap", pin: lanternItem.pin_number, name: "LED paper lanterns", price: newPrice, store: "Party City" },
      };
    }
  }

  if (msg.includes("more") && (msg.includes("festive") || msg.includes("sparkle") || msg.includes("party"))) {
    return {
      message: "On it — more sparkle, still under budget. Your locked items stay put.",
      action: { type: "redesign", mood: "Festive" },
    };
  }

  if (msg.includes("cheaper") || msg.includes("budget") || msg.includes("over") || msg.includes("fit")) {
    return {
      message: `Here's how I'd fit it — same look, two cheaper swaps. The garland kit can come from Dollar Tree instead of Amazon ($7.50 vs $14.99), and the sequin runner has a blush alternative at Dollar Tree ($1.25 vs $8.97). That saves $15.21.`,
      action: { type: "fit-to-budget" },
    };
  }

  if (msg.includes("night") || msg.includes("evening") || msg.includes("dark")) {
    return {
      message: "Here's the evening view. The string lights and your floor lamp carry the room — switch the overhead light off for the party.",
      action: { type: "view", view: "evening" },
    };
  }

  if (msg.includes("day") || msg.includes("morning") || msg.includes("light")) {
    return {
      message: "Here's the daytime view. Natural light from the window brightens the whole room.",
      action: { type: "view", view: "day" },
    };
  }

  if (msg.includes("remove") || msg.includes("delete") || msg.includes("get rid")) {
    const words = msg.split(/\s+/);
    const item = body.current_items.find(i =>
      words.some(w => i.name.toLowerCase().includes(w) && w.length > 3)
    );
    if (item) {
      return {
        message: `Removed ${item.name} from your list. Your total is now $${((totalCents - item.price_cents * item.quantity) / 100).toFixed(2)}.`,
        action: { type: "remove-item", pin: item.pin_number },
      };
    }
  }

  if (msg.includes("add") || msg.includes("need") || msg.includes("want")) {
    return {
      message: `Great idea! I'll suggest an item that fits your ${ctx.mood?.toLowerCase() ?? "cozy"} ${ctx.room_type.toLowerCase()} design. Make sure it's within your ${ctx.damage_level} damage rules.`,
      action: { type: "add-item" },
      new_items: [{
        name: "Decorative item",
        store: "Target",
        price_cents: 999,
        quantity: 1,
        category: "Decor",
        damage_badge: ctx.damage_level === "none" ? "no-damage" : "minor",
      }],
    };
  }

  return {
    message: `Got it! I'll work on that for your ${ctx.title} design. Tell me more about what you're looking for, or try asking about swaps, budget, or the evening view.`,
    action: { type: "info" },
  };
}