/*
# Add design_image_url to design_versions and create design-images storage bucket

## Changes

1. Adds `design_image_url` column to `design_versions` table — stores the URL of an AI-generated room design image
2. Creates a `design-images` storage bucket (private, 10MB limit) for storing AI-generated room design images
3. Adds storage policies so users can only access their own generated images (scoped by user_id folder path)

## Security
- Storage bucket is private (not public)
- Upload/read/delete policies scoped by user_id in file path: `user_id/filename`
- Only authenticated users can access their own generated design images
*/

-- Add design_image_url column to design_versions
ALTER TABLE design_versions ADD COLUMN IF NOT EXISTS design_image_url text;

-- Create the design-images storage bucket (private)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'design-images',
  'design-images',
  false,
  10485760,
  ARRAY['image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: users can only access files in their own user_id/ folder
DROP POLICY IF EXISTS "select_own_design_images" ON storage.objects;
CREATE POLICY "select_own_design_images" ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'design-images' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "insert_own_design_images" ON storage.objects;
CREATE POLICY "insert_own_design_images" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'design-images' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "update_own_design_images" ON storage.objects;
CREATE POLICY "update_own_design_images" ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'design-images' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'design-images' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "delete_own_design_images" ON storage.objects;
CREATE POLICY "delete_own_design_images" ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'design-images' AND (storage.foldername(name))[1] = auth.uid()::text);