/*
# SpaceLift — initial schema

## Purpose
SpaceLift helps renters design their rental space within budget and rental constraints.
This migration creates the core data model for multi-user projects.

## New Tables

1. `projects` — A design project for a rental space.
   - id (uuid, PK)
   - user_id (uuid, owner, defaults to auth.uid())
   - title (text, e.g. "Maya's 30th")
   - room_type (text, e.g. "Living room", "Studio", "Bedroom")
   - occasion (text, e.g. "Birthday party", "Everyday")
   - budget_cents (integer, budget in cents; 0 = rearrange-only)
   - budget_cap (text, "hard" | "soft" | "none")
   - wall_width_ft (numeric, wall measurement)
   - wall_width_in (integer, inches portion)
   - ceiling_height_ft (integer, optional)
   - damage_level (text, "none" | "minor" | "anything")
   - mood (text, e.g. "Festive", "Cozy", "Sleek", "Minimalist")
   - lighting_recipe (jsonb, {ambient, task, accent} percentages)
   - constraints (jsonb, additional constraint flags)
   - status (text, "draft" | "active" | "archived")
   - created_at (timestamptz)
   - updated_at (timestamptz)

2. `design_versions` — A versioned design within a project.
   - id (uuid, PK)
   - project_id (uuid, FK to projects)
   - user_id (uuid, owner, defaults to auth.uid())
   - version_number (integer, sequential per project)
   - label (text, e.g. "First design", "Lights → black wire")
   - total_cents (integer, total cost in cents)
   - summary (text, AI-generated summary of the design)
   - room_config (jsonb, serialized room render state)
   - is_current (boolean, whether this is the active version)
   - created_at (timestamptz)

3. `design_items` — Items in a design version's shopping list.
   - id (uuid, PK)
   - version_id (uuid, FK to design_versions)
   - user_id (uuid, owner, defaults to auth.uid())
   - pin_number (integer, the numbered pin on the room render)
   - name (text, e.g. "String lights")
   - store (text, e.g. "Target")
   - price_cents (integer)
   - quantity (integer, default 1)
   - category (text, "Lighting" | "Decor" | "Textiles" | "Tableware" | "Furniture")
   - damage_badge (text, "no-damage" | "minor" | "needs-ok")
   - wire_color (text, optional, e.g. "black", "white")
   - locked (boolean, user locked this item from swaps)
   - already_own (boolean, user already has this item)
   - notes (text, optional user notes)
   - sort_order (integer)
   - created_at (timestamptz)

4. `chat_messages` — Chat conversation between user and SpaceLift assistant.
   - id (uuid, PK)
   - project_id (uuid, FK to projects)
   - user_id (uuid, owner, defaults to auth.uid())
   - role (text, "user" | "assistant")
   - content (text)
   - action_data (jsonb, structured action like swap/lock/notification)
   - created_at (timestamptz)

5. `move_steps` — Steps for rearrange-what-you-own plans.
   - id (uuid, PK)
   - project_id (uuid, FK to projects)
   - user_id (uuid, owner, defaults to auth.uid())
   - step_number (integer)
   - title (text)
   - from_location (text)
   - to_location (text)
   - effort (text, "Light" | "Medium" | "Heavy")
   - time_minutes (integer)
   - tip (text)
   - needs_helper (boolean)
   - created_at (timestamptz)

## Security
- RLS enabled on ALL tables.
- All policies scoped to `authenticated` with `auth.uid() = user_id` ownership checks.
- Owner columns default to `auth.uid()` so inserts work without client passing user_id.
- No `FOR ALL` policies — 4 separate policies per table (SELECT/INSERT/UPDATE/DELETE).
*/

-- ============================================================================
-- PROJECTS
-- ============================================================================
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'Untitled project',
  room_type text NOT NULL DEFAULT 'Living room',
  occasion text DEFAULT 'Everyday',
  budget_cents integer NOT NULL DEFAULT 0,
  budget_cap text NOT NULL DEFAULT 'hard' CHECK (budget_cap IN ('hard', 'soft', 'none')),
  wall_width_ft numeric DEFAULT 12,
  wall_width_in integer DEFAULT 0,
  ceiling_height_ft integer,
  damage_level text NOT NULL DEFAULT 'none' CHECK (damage_level IN ('none', 'minor', 'anything')),
  mood text DEFAULT 'Cozy',
  lighting_recipe jsonb DEFAULT '{"ambient": 40, "task": 35, "accent": 25}',
  constraints jsonb DEFAULT '{}',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_projects" ON projects;
CREATE POLICY "select_own_projects" ON projects FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_projects" ON projects;
CREATE POLICY "insert_own_projects" ON projects FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_projects" ON projects;
CREATE POLICY "update_own_projects" ON projects FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_projects" ON projects;
CREATE POLICY "delete_own_projects" ON projects FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- DESIGN VERSIONS
-- ============================================================================
CREATE TABLE IF NOT EXISTS design_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  version_number integer NOT NULL DEFAULT 1,
  label text NOT NULL DEFAULT 'First design',
  total_cents integer NOT NULL DEFAULT 0,
  summary text DEFAULT '',
  room_config jsonb DEFAULT '{}',
  is_current boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, version_number)
);

ALTER TABLE design_versions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_versions" ON design_versions;
CREATE POLICY "select_own_versions" ON design_versions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_versions" ON design_versions;
CREATE POLICY "insert_own_versions" ON design_versions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_versions" ON design_versions;
CREATE POLICY "update_own_versions" ON design_versions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_versions" ON design_versions;
CREATE POLICY "delete_own_versions" ON design_versions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- DESIGN ITEMS
-- ============================================================================
CREATE TABLE IF NOT EXISTS design_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version_id uuid NOT NULL REFERENCES design_versions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  pin_number integer NOT NULL DEFAULT 0,
  name text NOT NULL,
  store text DEFAULT '',
  price_cents integer NOT NULL DEFAULT 0,
  quantity integer NOT NULL DEFAULT 1,
  category text NOT NULL DEFAULT 'Decor' CHECK (category IN ('Lighting', 'Decor', 'Textiles', 'Tableware', 'Furniture')),
  damage_badge text NOT NULL DEFAULT 'no-damage' CHECK (damage_badge IN ('no-damage', 'minor', 'needs-ok')),
  wire_color text,
  locked boolean NOT NULL DEFAULT false,
  already_own boolean NOT NULL DEFAULT false,
  notes text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE design_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_items" ON design_items;
CREATE POLICY "select_own_items" ON design_items FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_items" ON design_items;
CREATE POLICY "insert_own_items" ON design_items FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_items" ON design_items;
CREATE POLICY "update_own_items" ON design_items FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_items" ON design_items;
CREATE POLICY "delete_own_items" ON design_items FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- CHAT MESSAGES
-- ============================================================================
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  action_data jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_messages" ON chat_messages;
CREATE POLICY "select_own_messages" ON chat_messages FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_messages" ON chat_messages;
CREATE POLICY "insert_own_messages" ON chat_messages FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_messages" ON chat_messages;
CREATE POLICY "update_own_messages" ON chat_messages FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_messages" ON chat_messages;
CREATE POLICY "delete_own_messages" ON chat_messages FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- MOVE STEPS (for rearrange-what-you-own plans)
-- ============================================================================
CREATE TABLE IF NOT EXISTS move_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  step_number integer NOT NULL DEFAULT 1,
  title text NOT NULL,
  from_location text DEFAULT '',
  to_location text DEFAULT '',
  effort text NOT NULL DEFAULT 'Light' CHECK (effort IN ('Light', 'Medium', 'Heavy')),
  time_minutes integer NOT NULL DEFAULT 5,
  tip text DEFAULT '',
  needs_helper boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE move_steps ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_moves" ON move_steps;
CREATE POLICY "select_own_moves" ON move_steps FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_moves" ON move_steps;
CREATE POLICY "insert_own_moves" ON move_steps FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_moves" ON move_steps;
CREATE POLICY "update_own_moves" ON move_steps FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_moves" ON move_steps;
CREATE POLICY "delete_own_moves" ON move_steps FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_versions_project_id ON design_versions(project_id);
CREATE INDEX IF NOT EXISTS idx_versions_user_id ON design_versions(user_id);
CREATE INDEX IF NOT EXISTS idx_items_version_id ON design_items(version_id);
CREATE INDEX IF NOT EXISTS idx_items_user_id ON design_items(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_project_id ON chat_messages(project_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON chat_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_moves_project_id ON move_steps(project_id);
CREATE INDEX IF NOT EXISTS idx_moves_user_id ON move_steps(user_id);

-- Updated_at trigger for projects
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS projects_updated_at ON projects;
CREATE TRIGGER projects_updated_at BEFORE UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();