/*
# Add storage bucket for room photos and photo_url column

## Changes

1. Creates a `room-photos` storage bucket (private, 5MB limit)
2. Adds `photo_url` column to `projects` table (stores the public/path URL of uploaded photo)
3. Adds storage policies so users can only access their own photos (scoped by user_id folder path)

## Security
- Storage bucket is private (not public)
- Upload/read/delete policies scoped by user_id in file path: `user_id/filename`
- Only authenticated users can access their own photos
*/

-- Add photo_url column to projects
ALTER TABLE projects ADD COLUMN IF NOT EXISTS photo_url text;

-- Create the room-photos storage bucket (private)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'room-photos',
  'room-photos',
  false,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: users can only access files in their own user_id/ folder
DROP POLICY IF EXISTS "select_own_photos" ON storage.objects;
CREATE POLICY "select_own_photos" ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'room-photos' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "insert_own_photos" ON storage.objects;
CREATE POLICY "insert_own_photos" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'room-photos' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "update_own_photos" ON storage.objects;
CREATE POLICY "update_own_photos" ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'room-photos' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'room-photos' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "delete_own_photos" ON storage.objects;
CREATE POLICY "delete_own_photos" ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'room-photos' AND (storage.foldername(name))[1] = auth.uid()::text);