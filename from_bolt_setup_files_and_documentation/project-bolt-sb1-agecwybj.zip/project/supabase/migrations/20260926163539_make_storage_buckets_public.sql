-- Make both storage buckets public so images can be displayed in <img> tags
-- Private buckets require signed URLs which don't work with simple <img src="...">

UPDATE storage.buckets SET public = true WHERE id IN ('room-photos', 'design-images');