import type { Project, DesignItem, IntakeData, ItemCategory, DamageBadge } from '@/types';

export interface GeneratedDesign {
  label: string;
  summary: string;
  totalCents: number;
  items: Omit<DesignItem, 'id' | 'version_id' | 'user_id' | 'created_at'>[];
  roomConfig: Record<string, unknown>;
}

interface TemplateItem {
  pin: number;
  name: string;
  store: string;
  priceCents: number;
  quantity: number;
  category: ItemCategory;
  damageBadge: DamageBadge;
  wireColor?: string;
}

const FESTIVE_ITEMS: TemplateItem[] = [
  { pin: 1, name: 'Balloon garland kit', store: 'Amazon', priceCents: 1499, quantity: 1, category: 'Decor', damageBadge: 'no-damage' },
  { pin: 2, name: 'Blush table runner', store: 'Dollar Tree', priceCents: 125, quantity: 1, category: 'Textiles', damageBadge: 'no-damage' },
  { pin: 3, name: 'Paper lanterns set', store: 'Party City', priceCents: 799, quantity: 6, category: 'Decor', damageBadge: 'no-damage' },
  { pin: 4, name: 'Gold fringe backdrop', store: 'Amazon', priceCents: 1299, quantity: 1, category: 'Decor', damageBadge: 'no-damage' },
  { pin: 5, name: 'String lights, warm white', store: 'Target', priceCents: 1000, quantity: 1, category: 'Lighting', damageBadge: 'no-damage', wireColor: 'white' },
  { pin: 6, name: 'Sequin tablecloth', store: 'Walmart', priceCents: 897, quantity: 1, category: 'Tableware', damageBadge: 'no-damage' },
  { pin: 7, name: 'LED tea lights (24pk)', store: 'Amazon', priceCents: 1199, quantity: 1, category: 'Lighting', damageBadge: 'no-damage' },
  { pin: 8, name: 'Cupcake stand, 3-tier', store: 'Walmart', priceCents: 597, quantity: 1, category: 'Tableware', damageBadge: 'no-damage' },
  { pin: 9, name: 'Tassel banner', store: 'Party City', priceCents: 549, quantity: 1, category: 'Decor', damageBadge: 'no-damage' },
];

const COZY_ITEMS: TemplateItem[] = [
  { pin: 1, name: 'Throw blanket, chunky knit', store: 'Target', priceCents: 2500, quantity: 1, category: 'Textiles', damageBadge: 'no-damage' },
  { pin: 2, name: 'Floor lamp, warm bulb', store: 'IKEA', priceCents: 3999, quantity: 1, category: 'Lighting', damageBadge: 'no-damage' },
  { pin: 3, name: 'Linen cushion covers (2pk)', store: 'IKEA', priceCents: 1499, quantity: 1, category: 'Textiles', damageBadge: 'no-damage' },
  { pin: 4, name: 'Scented candle set', store: 'Target', priceCents: 1299, quantity: 1, category: 'Decor', damageBadge: 'no-damage' },
  { pin: 5, name: 'Area rug, 5x7', store: 'Walmart', priceCents: 4999, quantity: 1, category: 'Textiles', damageBadge: 'no-damage' },
];

const SLEEK_ITEMS: TemplateItem[] = [
  { pin: 1, name: 'Track lighting kit', store: 'IKEA', priceCents: 4999, quantity: 1, category: 'Lighting', damageBadge: 'minor' },
  { pin: 2, name: 'Glass vase, tall', store: 'CB2', priceCents: 2999, quantity: 1, category: 'Decor', damageBadge: 'no-damage' },
  { pin: 3, name: 'Velvet throw pillow', store: 'West Elm', priceCents: 3500, quantity: 2, category: 'Textiles', damageBadge: 'no-damage' },
  { pin: 4, name: 'Mirror, round 24in', store: 'IKEA', priceCents: 3999, quantity: 1, category: 'Decor', damageBadge: 'minor' },
  { pin: 5, name: 'LED bar shelf light', store: 'Amazon', priceCents: 2499, quantity: 1, category: 'Lighting', damageBadge: 'no-damage' },
  { pin: 6, name: 'Faux marble tray', store: 'CB2', priceCents: 1999, quantity: 1, category: 'Tableware', damageBadge: 'no-damage' },
];

const MINIMALIST_ITEMS: TemplateItem[] = [
  { pin: 1, name: 'Desk lamp, adjustable', store: 'IKEA', priceCents: 1999, quantity: 1, category: 'Lighting', damageBadge: 'no-damage' },
  { pin: 2, name: 'Cotton throw, neutral', store: 'Target', priceCents: 1799, quantity: 1, category: 'Textiles', damageBadge: 'no-damage' },
  { pin: 3, name: 'Ceramic planter', store: 'IKEA', priceCents: 999, quantity: 1, category: 'Decor', damageBadge: 'no-damage' },
  { pin: 4, name: 'Woven basket, large', store: 'Target', priceCents: 2499, quantity: 1, category: 'Decor', damageBadge: 'no-damage' },
];

function pickTemplate(mood: string): TemplateItem[] {
  const m = mood.toLowerCase();
  if (m.includes('festive') || m.includes('party')) return FESTIVE_ITEMS;
  if (m.includes('sleek')) return SLEEK_ITEMS;
  if (m.includes('minimal')) return MINIMALIST_ITEMS;
  return COZY_ITEMS;
}

function adjustForDamage(
  items: TemplateItem[],
  damage: 'none' | 'minor' | 'anything'
): TemplateItem[] {
  if (damage === 'none') {
    return items.filter((i) => i.damageBadge === 'no-damage');
  }
  if (damage === 'minor') {
    return items.filter((i) => i.damageBadge !== 'needs-ok');
  }
  return items;
}

function adjustForBudget(
  items: TemplateItem[],
  budgetCents: number
): TemplateItem[] {
  if (budgetCents === 0) return items;
  let total = items.reduce((s, i) => s + i.priceCents * i.quantity, 0);
  if (total <= budgetCents) return items;

  const sorted = [...items].sort((a, b) => b.priceCents - a.priceCents);
  for (const item of sorted) {
    if (total <= budgetCents) break;
    const cheaper: Record<string, number> = {
      'Balloon garland kit': 750,
      'Sequin tablecloth': 125,
      'Area rug, 5x7': 2999,
      'Floor lamp, warm bulb': 2499,
      'Track lighting kit': 3499,
      'Mirror, round 24in': 2499,
    };
    const newPrice = cheaper[item.name];
    if (newPrice && newPrice < item.priceCents) {
      total -= (item.priceCents - newPrice) * item.quantity;
      item.priceCents = newPrice;
      item.store = item.store === 'Amazon' ? 'Dollar Tree' : item.store === 'Walmart' ? 'Dollar Tree' : 'IKEA';
    }
  }
  return items;
}

export function generateDesign(
  intake: IntakeData | Project,
  isFromIntake = false
): GeneratedDesign {
  const mood = isFromIntake
    ? (intake as IntakeData).mood
    : (intake as Project).mood ?? 'Cozy';
  const damage = isFromIntake
    ? (intake as IntakeData).damageLevel
    : (intake as Project).damage_level;
  const budgetCents = isFromIntake
    ? (intake as IntakeData).budgetCents
    : (intake as Project).budget_cents;
  const roomType = isFromIntake
    ? (intake as IntakeData).roomType
    : (intake as Project).room_type;
  const occasion = isFromIntake
    ? (intake as IntakeData).occasion
    : (intake as Project).occasion ?? 'Everyday';

  let template = pickTemplate(mood);
  template = adjustForDamage(template, damage);
  template = adjustForBudget(template, budgetCents);

  const total = template.reduce((s, i) => s + i.priceCents * i.quantity, 0);

  const items: Omit<DesignItem, 'id' | 'version_id' | 'user_id' | 'created_at'>[] =
    template.map((t, idx) => ({
      pin_number: t.pin,
      name: t.name,
      store: t.store,
      price_cents: t.priceCents,
      quantity: t.quantity,
      category: t.category,
      damage_badge: t.damageBadge,
      wire_color: t.wireColor ?? null,
      locked: false,
      already_own: false,
      notes: null,
      sort_order: idx,
    }));

  const label = budgetCents === 0 ? 'Rearranged' : 'First design';
  const summary =
    budgetCents === 0
      ? `Your best makeover might cost $0. The sofa now faces the window, the bookshelf makes a little entry, and the armchair gets a reading nook in the best light.`
      : `Your ${mood.toLowerCase()} ${roomType.toLowerCase()} is ready. ${template.length} items, all ${damage === 'none' ? 'no-damage' : damage === 'minor' ? 'minor-damage' : 'various damage levels'}. Everything fits your budget.`;

  return {
    label,
    summary,
    totalCents: total,
    items,
    roomConfig: {
      mood,
      damage,
      occasion,
      wallWidth: isFromIntake
        ? (intake as IntakeData).wallWidthFt
        : (intake as Project).wall_width_ft ?? 12,
      lighting: isFromIntake
        ? (intake as IntakeData).lightingRecipe
        : (intake as Project).lighting_recipe ?? { ambient: 40, task: 35, accent: 25 },
    },
  };
}

export interface SwapSuggestion {
  name: string;
  store: string;
  priceCents: number;
  wireColor?: string;
  diff: number;
  reason: string;
}

export function getSwapSuggestions(
  item: Pick<DesignItem, 'name' | 'store' | 'price_cents' | 'wire_color'>
): SwapSuggestion[] {
  const suggestions: Record<string, SwapSuggestion[]> = {
    'String lights, warm white': [
      { name: 'String lights, warm white', store: 'Amazon', priceCents: 799, wireColor: 'black', diff: -201, reason: 'Same lights, black wire' },
      { name: 'String lights, battery LED', store: 'Target', priceCents: 1299, wireColor: 'white', diff: 299, reason: 'Battery powered, no outlet needed' },
      { name: 'Fairy lights, copper', store: 'Amazon', priceCents: 699, wireColor: 'copper', diff: -301, reason: 'Finer, more delicate look' },
    ],
    'Paper lanterns set': [
      { name: 'LED paper lanterns', store: 'Party City', priceCents: 1499, diff: 700, reason: 'They glow! Built-in LED' },
      { name: 'Honeycomb balls set', store: 'Dollar Tree', priceCents: 300, diff: -499, reason: 'Same vibe, much cheaper' },
    ],
  };

  return suggestions[item.name] ?? [
    { name: `${item.name} (alt)`, store: 'Amazon', priceCents: Math.round(item.price_cents * 0.8), diff: -Math.round(item.price_cents * 0.2), reason: 'Similar item, lower price' },
    { name: `${item.name} (premium)`, store: 'West Elm', priceCents: Math.round(item.price_cents * 1.5), diff: Math.round(item.price_cents * 0.5), reason: 'Higher quality version' },
  ];
}

export function getChatResponse(
  userMessage: string,
  context: { projectName: string; budgetCents: number; totalCents: number }
): { content: string; action?: Record<string, unknown> } {
  const msg = userMessage.toLowerCase();

  if (msg.includes('black wire')) {
    return {
      content: 'Swapped to black-wire lights, same price. Pin 5 updated.',
      action: { type: 'swap', pin: 5, property: 'wire_color', value: 'black' },
    };
  }
  if (msg.includes('light up') || msg.includes('glow') || msg.includes('led')) {
    const over = context.totalCents > context.budgetCents;
    return {
      content: over
        ? `Swapped to LED lanterns — they glow! That puts you $${((context.totalCents - context.budgetCents) / 100).toFixed(2)} over your cap. Would you like me to find a cheaper alternative?`
        : 'Swapped to LED lanterns — they glow! Still within budget.',
      action: { type: 'swap', pin: 7, name: 'LED paper lanterns', price: 1499 },
    };
  }
  if (msg.includes('more') && (msg.includes('festive') || msg.includes('sparkle'))) {
    return {
      content: 'On it — more sparkle, still under budget. Your locked items stay put.',
      action: { type: 'redesign', mood: 'Festive' },
    };
  }
  if (msg.includes('cheaper') || msg.includes('budget') || msg.includes('over')) {
    return {
      content: `Here's how I'd fit it — same look, two cheaper swaps. The garland kit can come from Dollar Tree instead of Amazon ($7.50 vs $14.99), and the sequin runner has a blush alternative at Dollar Tree ($1.25 vs $8.97). That saves $15.21.`,
      action: { type: 'fit-to-budget' },
    };
  }
  if (msg.includes('night') || msg.includes('evening')) {
    return {
      content: "Here's the evening view. The string lights and your floor lamp carry the room — switch the overhead light off for the party.",
      action: { type: 'view', view: 'evening' },
    };
  }
  return {
    content: `Got it! I'll work on that for your ${context.projectName} design. Tell me more about what you're looking for, or try asking about swaps, budget, or the evening view.`,
  };
}
