import { supabase } from './supabase';
import type {
  Project,
  DesignVersion,
  DesignItem,
  ChatMessage,
  MoveStep,
  LightingRecipe,
  BudgetCap,
  DamageLevel,
} from '@/types';

// ---- Projects ----

export async function fetchProjects(): Promise<Project[]> {
  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .order('updated_at', { ascending: false });
  if (error) throw error;
  return data as Project[];
}

export async function fetchProject(id: string): Promise<Project | null> {
  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as Project | null;
}

export async function createProject(input: {
  title: string;
  room_type: string;
  occasion?: string;
  budget_cents: number;
  budget_cap: BudgetCap;
  wall_width_ft?: number;
  wall_width_in?: number;
  ceiling_height_ft?: number | null;
  damage_level: DamageLevel;
  mood?: string;
  lighting_recipe?: LightingRecipe;
  status?: string;
}): Promise<Project> {
  const { data, error } = await supabase
    .from('projects')
    .insert({
      title: input.title,
      room_type: input.room_type,
      occasion: input.occasion ?? null,
      budget_cents: input.budget_cents,
      budget_cap: input.budget_cap,
      wall_width_ft: input.wall_width_ft ?? 12,
      wall_width_in: input.wall_width_in ?? 0,
      ceiling_height_ft: input.ceiling_height_ft ?? null,
      damage_level: input.damage_level,
      mood: input.mood ?? null,
      lighting_recipe: input.lighting_recipe ?? null,
      status: input.status ?? 'active',
    })
    .select()
    .single();
  if (error) throw error;
  return data as Project;
}

export async function updateProject(
  id: string,
  updates: Partial<Project>
): Promise<Project> {
  const { data, error } = await supabase
    .from('projects')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as Project;
}

export async function deleteProject(id: string): Promise<void> {
  const { error } = await supabase.from('projects').delete().eq('id', id);
  if (error) throw error;
}

// ---- Design Versions ----

export async function fetchVersions(projectId: string): Promise<DesignVersion[]> {
  const { data, error } = await supabase
    .from('design_versions')
    .select('*')
    .eq('project_id', projectId)
    .order('version_number', { ascending: true });
  if (error) throw error;
  return data as DesignVersion[];
}

export async function createVersion(
  projectId: string,
  input: {
    version_number: number;
    label: string;
    total_cents: number;
    summary?: string;
    room_config?: Record<string, unknown>;
    is_current?: boolean;
  }
): Promise<DesignVersion> {
  const { data, error } = await supabase
    .from('design_versions')
    .insert({
      project_id: projectId,
      version_number: input.version_number,
      label: input.label,
      total_cents: input.total_cents,
      summary: input.summary ?? '',
      room_config: input.room_config ?? {},
      is_current: input.is_current ?? true,
    })
    .select()
    .single();
  if (error) throw error;
  return data as DesignVersion;
}

export async function setCurrentVersion(
  projectId: string,
  versionId: string
): Promise<void> {
  await supabase
    .from('design_versions')
    .update({ is_current: false })
    .eq('project_id', projectId);
  const { error } = await supabase
    .from('design_versions')
    .update({ is_current: true })
    .eq('id', versionId);
  if (error) throw error;
}

// ---- Design Items ----

export async function fetchItems(versionId: string): Promise<DesignItem[]> {
  const { data, error } = await supabase
    .from('design_items')
    .select('*')
    .eq('version_id', versionId)
    .order('sort_order', { ascending: true });
  if (error) throw error;
  return data as DesignItem[];
}

export async function updateItem(
  id: string,
  updates: Partial<DesignItem>
): Promise<DesignItem> {
  const { data, error } = await supabase
    .from('design_items')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as DesignItem;
}

export async function deleteItem(id: string): Promise<void> {
  const { error } = await supabase.from('design_items').delete().eq('id', id);
  if (error) throw error;
}

export async function insertItems(
  versionId: string,
  items: Omit<DesignItem, 'id' | 'version_id' | 'user_id' | 'created_at'>[]
): Promise<void> {
  const rows = items.map((item) => ({ ...item, version_id: versionId }));
  const { error } = await supabase.from('design_items').insert(rows);
  if (error) throw error;
}

// ---- Chat Messages ----

export async function fetchMessages(projectId: string): Promise<ChatMessage[]> {
  const { data, error } = await supabase
    .from('chat_messages')
    .select('*')
    .eq('project_id', projectId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data as ChatMessage[];
}

export async function createMessage(
  projectId: string,
  input: { role: 'user' | 'assistant'; content: string; action_data?: Record<string, unknown> | null }
): Promise<ChatMessage> {
  const { data, error } = await supabase
    .from('chat_messages')
    .insert({
      project_id: projectId,
      role: input.role,
      content: input.content,
      action_data: input.action_data ?? null,
    })
    .select()
    .single();
  if (error) throw error;
  return data as ChatMessage;
}

// ---- Move Steps ----

export async function fetchMoveSteps(projectId: string): Promise<MoveStep[]> {
  const { data, error } = await supabase
    .from('move_steps')
    .select('*')
    .eq('project_id', projectId)
    .order('step_number', { ascending: true });
  if (error) throw error;
  return data as MoveStep[];
}
