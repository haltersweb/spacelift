import { useState } from 'react';
import {
  Layers,
  Share,
  Sun,
  Moon,
  Pin,
  ArrowLeft,
  Check,
  LogOut,
  Home,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { RoomRender } from '@/components/RoomRender';
import { useAuth } from '@/lib/auth';
import { formatCurrency } from '@/lib/format';

interface ComparePageProps {
  onBack: () => void;
  onSignOut: () => void;
}

interface ComparePlan {
  letter: string;
  persona: string;
  budgetCents: number;
  rule: string;
  mood: string;
  uniqueCount: number;
  totalCents: number;
  lighting: { ambient: number; task: number; accent: number };
}

const PLANS: ComparePlan[] = [
  {
    letter: 'A',
    persona: 'Budget-friendly',
    budgetCents: 7500,
    rule: 'No drill',
    mood: 'Cozy',
    uniqueCount: 5,
    totalCents: 7317,
    lighting: { ambient: 60, task: 20, accent: 20 },
  },
  {
    letter: 'B',
    persona: 'Mid-range',
    budgetCents: 30000,
    rule: 'Minor OK',
    mood: 'Sleek',
    uniqueCount: 6,
    totalCents: 28499,
    lighting: { ambient: 45, task: 40, accent: 15 },
  },
  {
    letter: 'C',
    persona: 'Premium',
    budgetCents: 50000,
    rule: 'Anything goes',
    mood: 'Festive',
    uniqueCount: 9,
    totalCents: 47230,
    lighting: { ambient: 25, task: 15, accent: 60 },
  },
];

export function ComparePage({ onBack, onSignOut }: ComparePageProps) {
  const [evening, setEvening] = useState(false);
  const [showPins, setShowPins] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="h-screen flex flex-col bg-cream-100 text-plum font-body overflow-hidden">
      <a href="#compare-main" className="skip-link">
        Skip to comparison
      </a>

      {/* Header */}
      <header
        className="flex-shrink-0 flex items-center gap-3 px-5 border-b border-cream-300 bg-cream-50"
        style={{ height: 60 }}
      >
        <Logo size={20} />
        <div className="w-px h-6 bg-cream-300" />
        <span className="font-bold text-sm">Living room · compare</span>
        <div className="flex-grow" />
        <button className="btn btn-secondary text-sm h-9">
          <Share size={15} aria-hidden="true" />
          Share
        </button>
        <button onClick={onBack} className="btn btn-ghost h-9 w-9 p-0" aria-label="Back">
          <Home size={16} aria-hidden="true" />
        </button>
        <button onClick={onSignOut} className="btn btn-ghost h-9 w-9 p-0" aria-label="Sign out">
          <LogOut size={16} aria-hidden="true" />
        </button>
      </header>

      {/* Title section */}
      <div className="flex-shrink-0 px-6 py-6 border-b border-cream-300 bg-lavender-100">
        <div className="max-w-workspace mx-auto">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-7 h-7 rounded-full bg-plum text-cream-50 flex items-center justify-center text-sm font-extrabold">
              2
            </span>
            <h1 className="font-display font-extrabold text-2xl">
              Same room, three renters
            </h1>
          </div>
          <p className="text-plum-light max-w-xl">
            One photo, one 12 ft wall. Different budgets and rules change the
            actual items, not just the style.
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex-shrink-0 flex items-center gap-3 px-6 py-3 border-b border-cream-300 bg-cream-50">
        <div className="flex bg-cream-200 rounded-xl p-1" role="group" aria-label="View mode">
          <button
            onClick={() => setEvening(false)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${
              !evening ? 'bg-cream-50 text-plum shadow-soft' : 'text-plum-light'
            }`}
            aria-pressed={!evening}
          >
            <Sun size={14} aria-hidden="true" />
            Day
          </button>
          <button
            onClick={() => setEvening(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${
              evening ? 'bg-cream-50 text-plum shadow-soft' : 'text-plum-light'
            }`}
            aria-pressed={evening}
          >
            <Moon size={14} aria-hidden="true" />
            Evening
          </button>
        </div>
        <button
          onClick={() => setShowPins(!showPins)}
          className={`btn text-sm h-9 ${showPins ? 'btn-sage' : 'btn-secondary'}`}
          aria-pressed={showPins}
        >
          <Pin size={14} aria-hidden="true" />
          {showPins ? 'Hide pins' : 'Show pins'}
        </button>
        <span className="text-xs text-plum-light ml-auto hidden lg:block">
          Drag in any column — all three move together
        </span>
      </div>

      {/* Three columns */}
      <div
        id="compare-main"
        className="flex-1 overflow-y-auto p-4 lg:p-6"
      >
        <div className="grid md:grid-cols-3 gap-4 max-w-workspace mx-auto">
          {PLANS.map((plan) => {
            const isOver = plan.totalCents > plan.budgetCents;
            const isSelected = selected === plan.letter;
            return (
              <div
                key={plan.letter}
                className={`card overflow-hidden transition-all ${
                  isSelected ? 'ring-2 ring-sage-400 shadow-elevated' : 'hover:shadow-card'
                }`}
              >
                {/* Plan header */}
                <div className="p-4 border-b border-cream-300 bg-cream-50">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-7 h-7 rounded-lg bg-plum text-cream-50 flex items-center justify-center font-display font-extrabold text-sm">
                      {plan.letter}
                    </span>
                    <span className="font-bold text-sm">{plan.persona}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <span className="pill pill-default h-6 text-2xs cursor-default">
                      {formatCurrency(plan.budgetCents)}
                    </span>
                    <span className="pill pill-default h-6 text-2xs cursor-default">
                      {plan.rule}
                    </span>
                    <span className="pill pill-default h-6 text-2xs cursor-default">
                      {plan.mood}
                    </span>
                  </div>
                </div>

                {/* Room render */}
                <RoomRender
                  mood={plan.mood}
                  evening={evening}
                  showPins={showPins}
                  width={400}
                  height={250}
                  className="w-full"
                />

                {/* Details */}
                <div className="p-4 space-y-3">
                  {/* Unique items */}
                  <div>
                    <p className="text-xs font-bold text-plum-light mb-1">
                      Unique to this plan
                    </p>
                    <p className="text-sm font-bold text-plum">
                      {plan.uniqueCount} items only here
                    </p>
                  </div>

                  {/* Budget */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-bold">
                        {formatCurrency(plan.totalCents)}
                      </span>
                      <span className="text-xs text-plum-light">
                        of {formatCurrency(plan.budgetCents)}
                      </span>
                    </div>
                    <div className="h-1.5 bg-cream-300 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-500 ${
                          isOver ? 'bg-error' : 'bg-sage-400'
                        }`}
                        style={{
                          width: `${Math.min(100, (plan.totalCents / plan.budgetCents) * 100)}%`,
                        }}
                      />
                    </div>
                    <p className="text-xs text-plum-light mt-1">
                      {isOver
                        ? `${formatCurrency(plan.totalCents - plan.budgetCents)} over`
                        : `${formatCurrency(plan.budgetCents - plan.totalCents)} left`}
                    </p>
                  </div>

                  {/* Lighting */}
                  <div>
                    <p className="text-xs font-bold text-plum-light mb-1.5">
                      Lighting mix
                    </p>
                    <div className="flex h-2 rounded-full overflow-hidden">
                      <div className="bg-accent-warm" style={{ width: `${plan.lighting.ambient}%` }} />
                      <div className="bg-sage-400" style={{ width: `${plan.lighting.task}%` }} />
                      <div className="bg-accent-coral" style={{ width: `${plan.lighting.accent}%` }} />
                    </div>
                    <div className="flex justify-between text-2xs text-plum-light mt-1 font-bold">
                      <span>A {plan.lighting.ambient}</span>
                      <span>T {plan.lighting.task}</span>
                      <span>X {plan.lighting.accent}</span>
                    </div>
                  </div>

                  {/* Action */}
                  <button
                    onClick={() => setSelected(plan.letter)}
                    className={`btn w-full text-sm h-9 ${
                      isSelected ? 'btn-sage' : 'btn-primary'
                    }`}
                  >
                    {isSelected ? (
                      <>
                        <Check size={14} aria-hidden="true" />
                        Selected
                      </>
                    ) : (
                      'Continue with this plan'
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Budget ladder */}
        <div className="max-w-workspace mx-auto mt-8">
          <h2 className="font-display font-bold text-lg mb-4">
            Budget ladder
          </h2>
          <div className="card p-4">
            <div className="space-y-3">
              {PLANS.map((plan) => (
                <div key={plan.letter} className="flex items-center gap-4">
                  <span className="w-7 h-7 rounded-lg bg-plum text-cream-50 flex items-center justify-center font-display font-extrabold text-sm flex-shrink-0">
                    {plan.letter}
                  </span>
                  <span className="text-sm font-bold w-32">{plan.persona}</span>
                  <div className="flex-1 h-2 bg-cream-300 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-sage-400 transition-all duration-500"
                      style={{ width: `${(plan.totalCents / PLANS[2].totalCents) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm font-bold w-20 text-right">
                    {formatCurrency(plan.totalCents)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom action bar */}
      {selected && (
        <div className="flex-shrink-0 flex items-center justify-between px-6 py-3 border-t border-cream-300 bg-cream-50 animate-slide-up" role="status" aria-live="polite">
          <span className="text-sm font-bold text-plum">
            Plan {selected} selected
          </span>
          <div className="flex gap-2">
            <button onClick={onBack} className="btn btn-ghost text-sm">
              <ArrowLeft size={15} aria-hidden="true" />
              Back
            </button>
            <button className="btn btn-primary text-sm">
              <Layers size={15} aria-hidden="true" />
              Start with plan {selected}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
