import { useState, useRef, useEffect, useCallback, type FormEvent } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Image as ImageIcon,
  Ruler,
  DollarSign,
  Lightbulb,
  ShieldCheck,
  Home,
  Sparkles,
  X,
  Loader2,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { RoomRender } from '@/components/RoomRender';
import {
  MOOD_OPTIONS,
  ROOM_TYPES,
  DAMAGE_LEVELS,
  BUDGET_CAPS,
  type IntakeData,
  type BudgetCap,
  type DamageLevel,
  type LightingRecipe,
} from '@/types';
import { dollarsToCents, formatCurrency } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';

interface IntakePageProps {
  onComplete: (data: IntakeData, uploadPhoto?: (file: File) => Promise<string | null>) => void;
  onBack: () => void;
}

const STEPS = [
  { id: 'photo', label: 'Photo', icon: ImageIcon },
  { id: 'room-type', label: 'Room', icon: Home },
  { id: 'wall-width', label: 'Measure', icon: Ruler },
  { id: 'ceiling', label: 'Height', icon: Ruler },
  { id: 'budget', label: 'Budget', icon: DollarSign },
  { id: 'cap', label: 'Cap type', icon: DollarSign },
  { id: 'mood', label: 'Mood', icon: Lightbulb },
  { id: 'lighting', label: 'Lighting', icon: Lightbulb },
  { id: 'damage', label: 'Lease rules', icon: ShieldCheck },
  { id: 'review', label: 'Review', icon: Check },
] as const;

const BUDGET_SNAP_POINTS = [0, 25, 50, 75, 100, 150, 200, 300, 500];

export function IntakePage({ onComplete, onBack }: IntakePageProps) {
  const { user } = useAuth();
  const [stepIndex, setStepIndex] = useState(0);
  const [data, setData] = useState<IntakeData>({
    title: '',
    occasion: 'Everyday',
    roomType: 'Living room',
    wallWidthFt: 12,
    wallWidthIn: 0,
    ceilingHeightFt: null,
    budgetCents: 7500,
    budgetCap: 'hard',
    mood: 'Cozy',
    damageLevel: 'none',
    lightingRecipe: { ambient: 40, task: 35, accent: 25 },
    photoUploaded: false,
    photoFile: null,
  });
  const [budgetInput, setBudgetInput] = useState('75');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const stepRef = useRef<HTMLDivElement>(null);

  // Lighting preview state
  const [lightingPreviewUrl, setLightingPreviewUrl] = useState<string | null>(null);
  const [lightingLoading, setLightingLoading] = useState(false);
  const [lightingError, setLightingError] = useState<string | null>(null);
  const [uploadedPhotoUrl, setUploadedPhotoUrl] = useState<string | null>(null);
  const lightingPreviewCache = useRef<Record<string, string>>({});
  const lightingRequestedMood = useRef<string | null>(null);

  const currentStep = STEPS[stepIndex];
  const isLast = stepIndex === STEPS.length - 1;
  const isFirst = stepIndex === 0;

  useEffect(() => {
    stepRef.current?.focus();
  }, [stepIndex]);

  const getSessionToken = useCallback(async (): Promise<string> => {
    const { data } = await supabase.auth.getSession();
    return data.session?.access_token ?? import.meta.env.VITE_SUPABASE_ANON_KEY;
  }, []);

  const uploadPhotoForPreview = useCallback(async (file: File): Promise<string | null> => {
    if (!user) return null;
    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
    const fileName = `${user.id}/${Date.now()}-lighting-input.${ext}`;
    try {
      const { error } = await supabase.storage
        .from('room-photos')
        .upload(fileName, file, { contentType: file.type, upsert: false });
      if (error) throw error;
      const { data: urlData } = supabase.storage
        .from('room-photos')
        .getPublicUrl(fileName);
      return urlData.publicUrl;
    } catch {
      return null;
    }
  }, [user]);

  const generateLightingPreview = useCallback(async (mood: string, photoUrl: string) => {
    if (lightingPreviewCache.current[mood]) {
      setLightingPreviewUrl(lightingPreviewCache.current[mood]);
      return;
    }
    setLightingLoading(true);
    setLightingError(null);
    try {
      const token = await getSessionToken();
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-design`;
      const resp = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          mode: 'generate-lighting-preview',
          photo_url: photoUrl,
          room_type: data.roomType,
          mood,
          lighting_recipe: data.lightingRecipe,
          damage_level: data.damageLevel,
        }),
      });
      if (!resp.ok) {
        const errBody = await resp.text().catch(() => '');
        throw new Error(`Preview failed (${resp.status}): ${errBody.slice(0, 150)}`);
      }
      const result = await resp.json();
      if (result.error) throw new Error(result.error);
      if (result.preview_url) {
        lightingPreviewCache.current[mood] = result.preview_url;
        setLightingPreviewUrl(result.preview_url);
      }
    } catch (err) {
      setLightingError(err instanceof Error ? err.message : 'Failed to generate preview');
    } finally {
      setLightingLoading(false);
    }
  }, [data.roomType, data.lightingRecipe, data.damageLevel, getSessionToken]);

  // When entering the lighting step with a photo, upload it and generate the preview
  useEffect(() => {
    if (currentStep.id !== 'lighting') return;
    if (!photoPreview || !data.photoFile) return;
    if (lightingRequestedMood.current === data.mood && lightingPreviewUrl) return;

    (async () => {
      let photoUrl = uploadedPhotoUrl;
      if (!photoUrl && data.photoFile) {
        photoUrl = await uploadPhotoForPreview(data.photoFile);
        if (photoUrl) setUploadedPhotoUrl(photoUrl);
      }
      if (photoUrl) {
        lightingRequestedMood.current = data.mood;
        generateLightingPreview(data.mood, photoUrl);
      }
    })();
  }, [currentStep.id, photoPreview, data.photoFile, data.mood, uploadedPhotoUrl, lightingPreviewUrl, uploadPhotoForPreview, generateLightingPreview]);

  const update = (updates: Partial<IntakeData>) => {
    setData((prev) => ({ ...prev, ...updates }));
  };

  const handlePhotoSelect = async (file: File) => {
    setUploadError(null);
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Photo must be under 5MB.');
      return;
    }
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select an image file.');
      return;
    }
    // Show preview immediately
    const previewUrl = URL.createObjectURL(file);
    setPhotoPreview(previewUrl);
    update({ photoUploaded: true, photoFile: file });
  };

  const uploadPhoto = async (file: File): Promise<string | null> => {
    if (!user) return null;
    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
    const fileName = `${user.id}/${Date.now()}-room-photo.${ext}`;
    setUploading(true);
    try {
      const { error } = await supabase.storage
        .from('room-photos')
        .upload(fileName, file, {
          contentType: file.type,
          upsert: false,
        });
      if (error) throw error;
      const { data: urlData } = supabase.storage
        .from('room-photos')
        .getPublicUrl(fileName);
      return urlData.publicUrl;
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Upload failed');
      return null;
    } finally {
      setUploading(false);
    }
  };

  const next = () => {
    if (isLast) {
      if (!data.title) {
        update({ title: `${data.roomType} · ${data.occasion}` });
      }
      onComplete({ ...data, title: data.title || `${data.roomType} · ${data.occasion}` }, uploadPhoto);
    } else {
      setStepIndex((prev) => Math.min(prev + 1, STEPS.length - 1));
    }
  };

  const prev = () => {
    if (isFirst) {
      onBack();
    } else {
      setStepIndex((prev) => Math.max(prev - 1, 0));
    }
  };

  const handleBudgetChange = (val: string) => {
    setBudgetInput(val);
    const num = parseInt(val, 10);
    if (!isNaN(num)) {
      update({ budgetCents: dollarsToCents(num) });
    } else if (val === '') {
      update({ budgetCents: 0 });
    }
  };

  const planPills: { label: string }[] = [];
  if (data.photoUploaded) planPills.push({ label: 'Photo uploaded' });
  planPills.push({ label: data.roomType });
  if (data.budgetCents > 0) {
    planPills.push({
      label: `${formatCurrency(data.budgetCents)} · ${BUDGET_CAPS.find((c) => c.value === data.budgetCap)?.short}`,
    });
  } else {
    planPills.push({ label: 'Rearrange only · $0' });
  }
  planPills.push({ label: data.mood });
  planPills.push({
    label: DAMAGE_LEVELS.find((d) => d.value === data.damageLevel)?.short ?? 'No damage',
  });

  return (
    <div className="min-h-screen bg-cream-100 text-plum font-body flex flex-col">
      <a href="#intake-main" className="skip-link">
        Skip to intake form
      </a>

      {/* Header */}
      <header className="flex-shrink-0 h-16 border-b border-cream-300 bg-cream-50 flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <Logo size={20} />
          <div className="w-px h-6 bg-cream-300" />
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-plum">
              New project · {data.roomType.toLowerCase()}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-lavender-100 text-plum-light text-xs font-bold">
              Draft
            </span>
          </div>
        </div>
        <button
          onClick={onBack}
          className="btn btn-ghost text-plum-light text-sm"
          aria-label="Cancel and go back"
        >
          <X size={16} aria-hidden="true" />
          Cancel
        </button>
      </header>

      {/* Progress bar */}
      <div
        className="flex-shrink-0 h-1 bg-cream-300"
        role="progressbar"
        aria-valuenow={stepIndex + 1}
        aria-valuemin={1}
        aria-valuemax={STEPS.length}
        aria-label={`Step ${stepIndex + 1} of ${STEPS.length}`}
      >
        <div
          className="h-full bg-sage-400 transition-all duration-300 ease-smooth"
          style={{ width: `${((stepIndex + 1) / STEPS.length) * 100}%` }}
        />
      </div>

      {/* Main */}
      <div
        id="intake-main"
        className="flex-1 flex flex-col lg:flex-row overflow-hidden"
      >
        {/* Left: steps + plan summary */}
        <aside className="flex-shrink-0 lg:w-64 border-b lg:border-b-0 lg:border-r border-cream-300 bg-cream-50 p-4 lg:p-6">
          <div className="flex lg:flex-col gap-2 overflow-x-auto lg:overflow-x-visible">
            <p className="hidden lg:block text-xs font-extrabold uppercase tracking-wider text-plum-light mb-3">
              Step {stepIndex + 1} of {STEPS.length}
            </p>
            <div className="flex lg:flex-col gap-1.5">
              {STEPS.map((step, i) => {
                const Icon = step.icon;
                const isDone = i < stepIndex;
                const isCurrent = i === stepIndex;
                return (
                  <div
                    key={step.id}
                    className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm font-bold transition-all flex-shrink-0 ${
                      isCurrent
                        ? 'bg-sage-200 text-plum'
                        : isDone
                          ? 'text-plum-light'
                          : 'text-plum-light/70'
                    }`}
                  >
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs flex-shrink-0 ${
                        isDone
                          ? 'bg-sage-400 text-cream-50'
                          : isCurrent
                            ? 'bg-sage-300 text-plum'
                            : 'bg-cream-300 text-plum-light'
                      }`}
                    >
                      {isDone ? (
                        <Check size={12} aria-hidden="true" />
                      ) : (
                        i + 1
                      )}
                    </span>
                    <span className="whitespace-nowrap">{step.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Plan so far */}
          <div className="hidden lg:block mt-6 pt-6 border-t border-cream-300">
            <p className="text-xs font-extrabold uppercase tracking-wider text-plum-light mb-3">
              Your plan so far
            </p>
            <div className="flex flex-wrap gap-2">
              {planPills.map((pill, i) => (
                <span
                  key={i}
                  className="inline-flex items-center px-2.5 py-1 rounded-full bg-lavender-100 text-plum text-xs font-bold"
                >
                  {pill.label}
                </span>
              ))}
            </div>
          </div>
        </aside>

        {/* Right: step content */}
        <main
          ref={stepRef}
          tabIndex={-1}
          className="flex-1 overflow-y-auto p-6 lg:p-10 focus:outline-none"
        >
          <div className="max-w-2xl mx-auto">
            <p className="text-sm text-plum-light mb-2">
              Every step is skippable
            </p>

            {currentStep.id === 'photo' && (
              <StepWrapper
                title="Hi! Drop in a photo of your room"
                subtitle="I'll make it party-ready (or cozy, or sleek — your call)."
              >
                <div
                  className="border-2 border-dashed border-cream-400 rounded-2xl p-8 text-center transition-colors hover:border-sage-400 cursor-pointer"
                  onClick={() => fileInputRef.current?.click()}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      fileInputRef.current?.click();
                    }
                  }}
                  role="button"
                  tabIndex={0}
                  aria-label="Upload a photo of your room"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/heic,image/heif"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.[0]) {
                        handlePhotoSelect(e.target.files[0]);
                      }
                    }}
                  />
                  {uploadError && (
                    <div role="alert" className="mb-3 p-3 rounded-xl bg-error-light text-error text-sm font-medium">
                      {uploadError}
                    </div>
                  )}
                  {data.photoUploaded && photoPreview ? (
                    <div className="space-y-3">
                      <img
                        src={photoPreview}
                        alt="Your room photo"
                        className="max-h-48 mx-auto rounded-xl shadow-soft"
                      />
                      <div className="w-10 h-10 mx-auto rounded-full bg-sage-200 flex items-center justify-center">
                        <Check size={20} className="text-sage-700" aria-hidden="true" />
                      </div>
                      <p className="font-bold text-plum">Photo ready!</p>
                      <p className="text-sm text-plum-light">
                        {data.photoFile?.name} · {Math.round((data.photoFile?.size ?? 0) / 1024)} KB
                      </p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setPhotoPreview(null);
                          setUploadError(null);
                          update({ photoUploaded: false, photoFile: null });
                        }}
                        className="text-sm text-plum-light hover:text-plum underline mt-2"
                      >
                        Replace photo
                      </button>
                    </div>
                  ) : uploading ? (
                    <div className="space-y-2">
                      <Loader2 size={28} className="mx-auto text-sage-600 animate-spin" aria-hidden="true" />
                      <p className="font-bold text-plum">Uploading...</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="w-16 h-16 mx-auto rounded-full bg-lavender-200 flex items-center justify-center">
                        <ImageIcon size={28} className="text-plum-light" aria-hidden="true" />
                      </div>
                      <p className="font-bold text-plum">
                        Click to upload a photo
                      </p>
                      <p className="text-sm text-plum-light">
                        JPG, PNG, WebP, or HEIC · Under 5MB · Optional
                      </p>
                    </div>
                  )}
                </div>
                <p className="text-sm text-plum-light mt-4 text-center">
                  No photo? No problem — I'll use a room layout that matches
                  your room type.
                </p>
              </StepWrapper>
            )}

            {currentStep.id === 'room-type' && (
              <StepWrapper
                title="What room are we designing?"
                subtitle="I'll pick a layout that matches."
              >
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {ROOM_TYPES.map((room) => (
                    <button
                      key={room}
                      onClick={() => update({ roomType: room })}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        data.roomType === room
                          ? 'border-sage-400 bg-sage-200 text-plum'
                          : 'border-cream-300 bg-cream-50 text-plum hover:border-lavender-300'
                      }`}
                    >
                      <Home size={20} className="mb-2" aria-hidden="true" />
                      <p className="font-bold text-sm">{room}</p>
                    </button>
                  ))}
                </div>
                <div className="mt-6">
                  <label htmlFor="occasion" className="block text-sm font-bold mb-2">
                    What's the occasion? (optional)
                  </label>
                  <input
                    id="occasion"
                    type="text"
                    value={data.occasion}
                    onChange={(e) => update({ occasion: e.target.value })}
                    className="input-field"
                    placeholder="Birthday party, Everyday, Housewarming..."
                  />
                </div>
              </StepWrapper>
            )}

            {currentStep.id === 'wall-width' && (
              <StepWrapper
                title="One quick measurement: how wide is this wall?"
                subtitle="I highlighted the main wall. Type the width — even a guess helps."
              >
                <div className="card p-6">
                  <div className="flex items-end gap-4 mb-6">
                    <div className="flex-1">
                      <label htmlFor="wall-ft" className="block text-sm font-bold mb-1.5">
                        Wall width
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          id="wall-ft"
                          type="number"
                          min="4"
                          max="50"
                          value={data.wallWidthFt}
                          onChange={(e) =>
                            update({ wallWidthFt: parseInt(e.target.value) || 0 })
                          }
                          className="input-field w-24 text-center"
                          aria-label="Wall width in feet"
                        />
                        <span className="text-sm font-bold text-plum-light">ft</span>
                        <input
                          id="wall-in"
                          type="number"
                          min="0"
                          max="11"
                          value={data.wallWidthIn}
                          onChange={(e) =>
                            update({ wallWidthIn: parseInt(e.target.value) || 0 })
                          }
                          className="input-field w-20 text-center"
                          aria-label="Wall width inches"
                        />
                        <span className="text-sm font-bold text-plum-light">in</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-plum-light bg-lavender-100 rounded-xl p-3">
                    <span className="font-bold">Not sure?</span> A standard
                    interior door is about 3 ft wide. Count how many would fit
                    across.
                  </p>
                </div>
                <button
                  onClick={() => update({ wallWidthFt: 12, wallWidthIn: 0 })}
                  className="btn btn-ghost text-sm mt-4 text-plum-light"
                >
                  Skip — sizes will be estimates
                </button>
              </StepWrapper>
            )}

            {currentStep.id === 'ceiling' && (
              <StepWrapper
                title="Ceiling height (optional)"
                subtitle="This helps with lighting and tall furniture. Skip if you're not sure."
              >
                <div className="card p-6">
                  <label htmlFor="ceiling-ft" className="block text-sm font-bold mb-1.5">
                    Ceiling height
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      id="ceiling-ft"
                      type="number"
                      min="6"
                      max="20"
                      value={data.ceilingHeightFt ?? ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        update({
                          ceilingHeightFt: val ? parseInt(val) : null,
                        });
                      }}
                      className="input-field w-24 text-center"
                      placeholder="8"
                      aria-label="Ceiling height in feet"
                    />
                    <span className="text-sm font-bold text-plum-light">ft</span>
                  </div>
                  <div className="mt-4 flex gap-2">
                    {[8, 9, 10, 12].map((h) => (
                      <button
                        key={h}
                        onClick={() => update({ ceilingHeightFt: h })}
                        className={`pill ${
                          data.ceilingHeightFt === h ? 'pill-active' : 'pill-default'
                        }`}
                      >
                        {h} ft
                      </button>
                    ))}
                  </div>
                </div>
                <button
                  onClick={() => update({ ceilingHeightFt: null })}
                  className="btn btn-ghost text-sm mt-4 text-plum-light"
                >
                  Skip — not sure
                </button>
              </StepWrapper>
            )}

            {currentStep.id === 'budget' && (
              <StepWrapper
                title="What's the budget?"
                subtitle="Tap a snap point or type any amount. Set $0 to rearrange what you own."
              >
                <div className="card p-6">
                  <div className="flex items-center gap-2 mb-6">
                    <span className="text-2xl font-extrabold text-plum">$</span>
                    <input
                      type="number"
                      min="0"
                      step="5"
                      value={budgetInput}
                      onChange={(e) => handleBudgetChange(e.target.value)}
                      className="input-field flex-1 text-2xl font-extrabold"
                      aria-label="Budget in dollars"
                    />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {BUDGET_SNAP_POINTS.map((amt) => (
                      <button
                        key={amt}
                        onClick={() => {
                          setBudgetInput(String(amt));
                          update({ budgetCents: dollarsToCents(amt) });
                        }}
                        className={`pill ${
                          data.budgetCents === dollarsToCents(amt)
                            ? 'pill-active'
                            : 'pill-default'
                        }`}
                      >
                        {amt === 0 ? 'Rearrange only' : `$${amt}`}
                      </button>
                    ))}
                  </div>
                  {data.budgetCents === 0 && (
                    <p className="mt-4 text-sm text-sage-700 bg-sage-100 rounded-xl p-3 font-medium">
                      <Sparkles size={14} className="inline mr-1" aria-hidden="true" />
                      We'll redesign by moving what you already own — no purchases needed.
                    </p>
                  )}
                </div>
              </StepWrapper>
            )}

            {currentStep.id === 'cap' && (
              <StepWrapper
                title="How strict is the budget?"
                subtitle="A hard cap means we never go over. Soft means we can suggest going slightly over with alternatives."
              >
                <div className="space-y-3">
                  {BUDGET_CAPS.map((cap) => (
                    <button
                      key={cap.value}
                      onClick={() => update({ budgetCap: cap.value as BudgetCap })}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all flex items-center justify-between ${
                        data.budgetCap === cap.value
                          ? 'border-sage-400 bg-sage-200'
                          : 'border-cream-300 bg-cream-50 hover:border-lavender-300'
                      }`}
                    >
                      <div>
                        <p className="font-bold text-plum">{cap.label}</p>
                        <p className="text-sm text-plum-light mt-0.5">
                          {cap.value === 'hard' && 'Never exceed the budget'}
                          {cap.value === 'soft' && 'Can suggest going over with alternatives'}
                          {cap.value === 'none' && 'Show options at any price'}
                        </p>
                      </div>
                      {data.budgetCap === cap.value && (
                        <Check size={20} className="text-sage-700" aria-hidden="true" />
                      )}
                    </button>
                  ))}
                </div>
              </StepWrapper>
            )}

            {currentStep.id === 'mood' && (
              <StepWrapper
                title="Now the fun part. How should it feel?"
                subtitle="Each card is the same room, lit a different way."
              >
                <div className="grid sm:grid-cols-2 gap-4">
                  {MOOD_OPTIONS.map((mood) => (
                    <button
                      key={mood.name}
                      onClick={() => {
                        update({
                          mood: mood.name,
                          lightingRecipe: { ambient: mood.a, task: mood.t, accent: mood.x },
                        });
                      }}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        data.mood === mood.name
                          ? 'border-sage-400 bg-sage-200 ring-2 ring-sage-400/30'
                          : 'border-cream-300 bg-cream-50 hover:border-lavender-300'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-display font-bold text-lg text-plum">
                            {mood.name}
                          </p>
                          <p className="text-xs text-plum-light">{mood.key}</p>
                        </div>
                        {data.mood === mood.name && (
                          <Check size={18} className="text-sage-700" aria-hidden="true" />
                        )}
                      </div>
                      <p className="text-sm text-plum-light leading-snug mb-3">
                        {mood.desc}
                      </p>
                      <div className="flex gap-1.5">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-lavender-100 text-plum-light font-bold">
                          A {mood.a}
                        </span>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-lavender-100 text-plum-light font-bold">
                          T {mood.t}
                        </span>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-lavender-100 text-plum-light font-bold">
                          X {mood.x}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
                <p className="text-sm text-plum-light mt-4">
                  <span className="font-bold">Festive</span> is suggested because
                  you're hosting a party.
                </p>
              </StepWrapper>
            )}

            {currentStep.id === 'lighting' && (
              <StepWrapper
                title="Lighting recipe"
                subtitle="Here's your room at evening with the lighting applied. Change the mood on the previous step to see a different look."
              >
                <div className="card p-6 space-y-4">
                  <div className="rounded-xl overflow-hidden border border-cream-300 relative">
                    {photoPreview && data.photoFile ? (
                      lightingLoading ? (
                        <div className="flex flex-col items-center justify-center py-20 px-6 bg-cream-100">
                          <div className="w-14 h-14 mb-4 rounded-2xl bg-sage-200 flex items-center justify-center animate-glow-pulse">
                            <Sparkles size={24} className="text-plum" aria-hidden="true" />
                          </div>
                          <p className="font-bold text-plum mb-1">
                            Generating evening lighting...
                          </p>
                          <p className="text-sm text-plum-light text-center max-w-xs">
                            I'm transforming your room photo to show it at evening with {data.mood.toLowerCase()} lighting.
                          </p>
                        </div>
                      ) : lightingPreviewUrl ? (
                        <img
                          src={lightingPreviewUrl}
                          alt={`Your ${data.roomType.toLowerCase()} at evening with ${data.mood.toLowerCase()} lighting`}
                          className="w-full h-auto block max-h-[325px] object-cover"
                        />
                      ) : lightingError ? (
                        <div className="flex flex-col items-center justify-center py-12 px-6">
                          <div className="w-12 h-12 mb-3 rounded-full bg-error-light flex items-center justify-center">
                            <X size={22} className="text-error" aria-hidden="true" />
                          </div>
                          <p className="font-bold text-plum mb-1">Couldn't generate preview</p>
                          <p className="text-sm text-plum-light text-center max-w-xs mb-3">{lightingError}</p>
                          <button
                            onClick={() => {
                              setLightingError(null);
                              lightingRequestedMood.current = null;
                              if (uploadedPhotoUrl) {
                                generateLightingPreview(data.mood, uploadedPhotoUrl);
                              }
                            }}
                            className="btn btn-secondary text-sm"
                          >
                            Try again
                          </button>
                        </div>
                      ) : (
                        <img
                          src={photoPreview}
                          alt={`Your ${data.roomType.toLowerCase()}`}
                          className="w-full h-auto block max-h-[325px] object-cover"
                        />
                      )
                    ) : (
                      <RoomRender
                        mood={data.mood}
                        evening
                        showPins={false}
                        width={520}
                        height={325}
                        className="w-full"
                      />
                    )}
                  </div>
                  {(() => {
                    const selected = MOOD_OPTIONS.find((m) => m.name === data.mood);
                    if (!selected) return null;
                    return (
                      <div>
                        <p className="font-bold text-plum mb-1">
                          {selected.name} · {selected.key}
                        </p>
                        <p className="text-sm text-plum-light mb-3">{selected.desc}</p>
                        <div className="flex h-4 rounded-full overflow-hidden">
                          <div
                            className="bg-accent-warm"
                            style={{ width: `${data.lightingRecipe.ambient}%` }}
                            title={`Ambient ${data.lightingRecipe.ambient}%`}
                          />
                          <div
                            className="bg-sage-400"
                            style={{ width: `${data.lightingRecipe.task}%` }}
                            title={`Task ${data.lightingRecipe.task}%`}
                          />
                          <div
                            className="bg-accent-coral"
                            style={{ width: `${data.lightingRecipe.accent}%` }}
                            title={`Accent ${data.lightingRecipe.accent}%`}
                          />
                        </div>
                        <div className="flex justify-between text-xs text-plum-light mt-1.5 font-bold">
                          <span>Ambient {data.lightingRecipe.ambient}%</span>
                          <span>Task {data.lightingRecipe.task}%</span>
                          <span>Accent {data.lightingRecipe.accent}%</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </StepWrapper>
            )}

            {currentStep.id === 'damage' && (
              <StepWrapper
                title="What can you do to the walls?"
                subtitle="This filters every item to match your lease rules."
              >
                <div className="space-y-3">
                  {DAMAGE_LEVELS.map((level) => (
                    <button
                      key={level.value}
                      onClick={() => update({ damageLevel: level.value as DamageLevel })}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all flex items-center justify-between ${
                        data.damageLevel === level.value
                          ? 'border-sage-400 bg-sage-200'
                          : 'border-cream-300 bg-cream-50 hover:border-lavender-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <ShieldCheck
                          size={20}
                          className={
                            data.damageLevel === level.value
                              ? 'text-sage-700'
                              : 'text-plum-light'
                          }
                          aria-hidden="true"
                        />
                        <div>
                          <p className="font-bold text-plum">{level.label}</p>
                          <p className="text-sm text-plum-light mt-0.5">
                            {level.value === 'none' && 'Command strips, freestanding items only'}
                            {level.value === 'minor' && 'Small nails, push pins, command strips OK'}
                            {level.value === 'anything' && 'Drilling, painting, wall mounts allowed'}
                          </p>
                        </div>
                      </div>
                      {data.damageLevel === level.value && (
                        <Check size={20} className="text-sage-700" aria-hidden="true" />
                      )}
                    </button>
                  ))}
                </div>
              </StepWrapper>
            )}

            {currentStep.id === 'review' && (
              <StepWrapper
                title="Ready to design!"
                subtitle="Here's what I'll work with. You can change anything later."
              >
                <div className="card p-6">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <ReviewItem label="Room" value={data.roomType} />
                    <ReviewItem label="Occasion" value={data.occasion || 'Everyday'} />
                    <ReviewItem label="Budget" value={data.budgetCents === 0 ? 'Rearrange only' : `${formatCurrency(data.budgetCents)} (${data.budgetCap})`} />
                    <ReviewItem label="Mood" value={data.mood} />
                    <ReviewItem label="Wall width" value={`${data.wallWidthFt} ft ${data.wallWidthIn} in`} />
                    <ReviewItem
                      label="Lease rules"
                      value={DAMAGE_LEVELS.find((d) => d.value === data.damageLevel)?.label ?? 'No damage'}
                    />
                  </div>
                </div>
                <div className="card p-6 mt-4">
                  <p className="text-sm font-bold mb-2">Preview</p>
                  {lightingPreviewUrl ? (
                    <div className="rounded-xl overflow-hidden border border-cream-300 relative">
                      <img
                        src={lightingPreviewUrl}
                        alt={`Your ${data.roomType.toLowerCase()} with ${data.mood.toLowerCase()} lighting`}
                        className="w-full h-auto block max-h-[325px] object-cover"
                      />
                    </div>
                  ) : photoPreview ? (
                    <div className="rounded-xl overflow-hidden border border-cream-300 relative">
                      <img
                        src={photoPreview}
                        alt={`Your ${data.roomType.toLowerCase()} preview`}
                        className="w-full h-auto block max-h-[325px] object-cover"
                      />
                    </div>
                  ) : (
                    <RoomRender
                      mood={data.mood}
                      showPins={false}
                      width={520}
                      height={325}
                      className="w-full rounded-xl overflow-hidden border border-cream-300"
                    />
                  )}
                </div>
              </StepWrapper>
            )}

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8">
              <button
                onClick={prev}
                className="btn btn-ghost text-plum-light"
              >
                <ArrowLeft size={16} aria-hidden="true" />
                {isFirst ? 'Back to home' : 'Back'}
              </button>
              <button
                onClick={next}
                className="btn btn-primary"
              >
                {isLast ? 'Generate my design' : 'Next'}
                {!isLast && <ArrowRight size={16} aria-hidden="true" />}
                {isLast && <Sparkles size={16} aria-hidden="true" />}
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function StepWrapper({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="animate-slide-up">
      <h2 className="font-display font-extrabold text-2xl lg:text-3xl mb-2">
        {title}
      </h2>
      <p className="text-plum-light mb-6">{subtitle}</p>
      {children}
    </div>
  );
}

function ReviewItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col">
      <span className="text-xs font-extrabold uppercase tracking-wider text-plum-light">
        {label}
      </span>
      <span className="font-bold text-plum mt-0.5">{value}</span>
    </div>
  );
}
