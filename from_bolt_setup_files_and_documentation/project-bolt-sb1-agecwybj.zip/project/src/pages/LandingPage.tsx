import { useState, useEffect } from 'react';
import {
  Sparkles,
  DollarSign,
  ShieldCheck,
  MessageSquare,
  ArrowRight,
  Moon,
  Layers,
  ShoppingBag,
  Check,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { RoomRender } from '@/components/RoomRender';

interface LandingPageProps {
  onStart: () => void;
  onSignIn: () => void;
}

export function LandingPage({ onStart, onSignIn }: LandingPageProps) {
  const [currentMood, setCurrentMood] = useState(0);
  const moods = ['Festive', 'Cozy', 'Sleek', 'Minimalist'];

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mediaQuery.matches) return;
    const interval = setInterval(() => {
      setCurrentMood((prev) => (prev + 1) % moods.length);
    }, 3500);
    return () => clearInterval(interval);
  }, [moods.length]);

  return (
    <div className="min-h-screen bg-cream-100 text-plum font-body">
      {/* Skip link */}
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>

      {/* Nav */}
      <nav className="sticky top-0 z-50 bg-cream-100/85 backdrop-blur-md border-b border-cream-300">
        <div className="max-w-workspace mx-auto px-6 h-16 flex items-center justify-between">
          <Logo />
        </div>
      </nav>

      {/* Hero */}
      <header
        id="main-content"
        className="relative overflow-hidden"
        style={{
          background:
            'linear-gradient(180deg, #F5F2E6 0%, #E4DEF2 100%)',
        }}
      >
        <div className="max-w-workspace mx-auto px-6 pt-16 pb-24 lg:pt-24 lg:pb-32">
          <div className="grid lg:grid-cols-[1.1fr_1fr] gap-12 items-center">
            <div className="animate-slide-up">
              <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-sage-200 text-plum text-sm font-bold mb-6">
                <Sparkles size={15} aria-hidden="true" />
                Design your rental without the guesswork
              </span>
              <h1 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl leading-[1.1] tracking-tight mb-6">
                Your space,
                <br />
                <span className="text-sage-700">designed within reach.</span>
              </h1>
              <p className="text-lg lg:text-xl text-plum-light leading-relaxed mb-8 max-w-lg">
                SpaceLift helps renters design their rental space within budget
                and lease constraints. Upload a photo, set your budget, and get
                a room design you can actually buy — no damage, no surprises.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={onStart}
                  className="btn btn-primary text-base px-6 py-3.5 h-auto"
                >
                  Design my space
                  <ArrowRight size={18} aria-hidden="true" />
                </button>
                <button
                  onClick={onSignIn}
                  className="btn btn-secondary text-base px-6 py-3.5 h-auto"
                >
                  I have an account
                </button>
              </div>
              <p className="text-sm text-plum-light mt-4">
                No sign-up needed to try · Saved on your account
              </p>
            </div>

            {/* Room preview */}
            <div
              className="relative animate-fade-in"
              aria-hidden="true"
            >
              <div className="card overflow-hidden shadow-elevated">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-cream-300 bg-cream-50">
                  <div className="flex gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-accent-coral/30" />
                    <span className="w-3 h-3 rounded-full bg-accent-warm/30" />
                    <span className="w-3 h-3 rounded-full bg-sage-400/30" />
                  </div>
                  <span className="text-xs font-bold text-plum-light ml-2">
                    {moods[currentMood]} preview
                  </span>
                </div>
                <RoomRender
                  mood={moods[currentMood]}
                  width={520}
                  height={325}
                  showPins={false}
                  className="w-full"
                />
                <div className="px-4 py-3 border-t border-cream-300 bg-cream-50 flex items-center justify-between">
                  <span className="text-sm font-bold text-plum">
                    $73.17 of $75
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-success">
                    <ShieldCheck size={14} aria-hidden="true" />
                    All lease-safe
                  </span>
                </div>
              </div>

              {/* Floating chat bubble */}
              <div className="absolute -bottom-4 -left-4 card shadow-elevated p-3 max-w-[220px] animate-slide-up">
                <div className="flex items-start gap-2">
                  <MessageSquare size={16} className="text-sage-600 mt-0.5" aria-hidden="true" />
                  <p className="text-xs font-medium text-plum leading-snug">
                    "Can the string lights be black wire?"
                  </p>
                </div>
                <p className="text-xs text-plum-light mt-1.5 pl-6">
                  Swapped to black-wire, same price ✓
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* How it works */}
      <section className="py-20 lg:py-28" aria-labelledby="how-heading">
        <div className="max-w-workspace mx-auto px-6">
          <h2
            id="how-heading"
            className="font-display font-extrabold text-3xl lg:text-4xl text-center mb-4"
          >
            Three steps to your new space
          </h2>
          <p className="text-center text-lg text-plum-light mb-14 max-w-xl mx-auto">
            No design skills needed. No measuring tape required. Just a photo
            and a budget.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: <Sparkles size={24} aria-hidden="true" />,
                title: 'Drop in a photo',
                desc: 'Take a picture of your room. SpaceLift reads the layout, the wall, the furniture.',
              },
              {
                icon: <DollarSign size={24} aria-hidden="true" />,
                title: 'Set your budget',
                desc: 'Tell us how much you can spend and your lease rules. We design within those limits.',
              },
              {
                icon: <ShoppingBag size={24} aria-hidden="true" />,
                title: 'Get a shopping list',
                desc: 'Every item is real, priced, and lease-safe. Buy where you want or swap anything.',
              },
            ].map((step, i) => (
              <div
                key={i}
                className="card p-8 hover:shadow-card transition-shadow duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-sage-200 text-plum flex items-center justify-center mb-5">
                  {step.icon}
                </div>
                <h3 className="font-display font-bold text-xl mb-2">
                  {step.title}
                </h3>
                <p className="text-plum-light leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section
        className="py-20 bg-lavender-100"
        aria-labelledby="features-heading"
      >
        <div className="max-w-workspace mx-auto px-6">
          <h2
            id="features-heading"
            className="font-display font-extrabold text-3xl lg:text-4xl text-center mb-14"
          >
            Built for renters, not homeowners
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: <ShieldCheck size={22} />, title: 'Lease-safe', desc: 'Every item tagged: no damage, minor, or needs OK. Filter by your lease rules.' },
              { icon: <DollarSign size={22} />, title: 'Budget-aware', desc: 'Set a hard cap, soft cap, or no limit. We keep you under — or suggest cheaper swaps.' },
              { icon: <MessageSquare size={22} />, title: 'Chat to redesign', desc: 'Type what you want changed. SpaceLift swaps items and re-renders instantly.' },
              { icon: <Moon size={22} />, title: 'Day & evening', desc: 'See your room in daylight or at night. Lighting changes everything.' },
              { icon: <Layers size={22} />, title: 'Version history', desc: 'Every change saves a version. Compare, restore, or branch from any point.' },
              { icon: <ShoppingBag size={22} />, title: 'Real shopping list', desc: 'Items from real stores with real prices. Copy list, export PDF, buy directly.' },
              { icon: <Check size={22} />, title: 'Rearrange for free', desc: 'Budget $0? We redesign by moving what you already own. No purchases needed.' },
              { icon: <Sparkles size={22} />, title: 'Compare plans', desc: 'Same room, three budgets. See how far your money goes before you spend.' },
            ].map((feat, i) => (
              <div
                key={i}
                className="card p-6 bg-cream-50 hover:shadow-card transition-all duration-200 hover:-translate-y-1"
              >
                <div className="w-10 h-10 rounded-lg bg-lavender-200 text-plum flex items-center justify-center mb-4">
                  {feat.icon}
                </div>
                <h3 className="font-bold text-base mb-1.5">{feat.title}</h3>
                <p className="text-sm text-plum-light leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 lg:py-28">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <h2 className="font-display font-extrabold text-3xl lg:text-4xl mb-4">
            Ready to see your space?
          </h2>
          <p className="text-lg text-plum-light mb-8">
            Start a free design now. Sign up to save your projects and come back
            anytime.
          </p>
          <button
            onClick={onStart}
            className="btn btn-primary text-base px-8 py-3.5 h-auto"
          >
            Start designing
            <ArrowRight size={18} aria-hidden="true" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-cream-300 py-8">
        <div className="max-w-workspace mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <Logo size={18} />
          <p className="text-sm text-plum-light">
            © 2026 SpaceLift · Designed for renters
          </p>
        </div>
      </footer>
    </div>
  );
}
