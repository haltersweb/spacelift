import { useState, useEffect, useCallback } from 'react';
import {
  Plus,
  Home,
  LogOut,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { RoomRender } from '@/components/RoomRender';
import { useAuth } from '@/lib/auth';
import { fetchProjects } from '@/lib/api';
import { formatCurrency, formatDate } from '@/lib/format';
import type { Project } from '@/types';

interface DashboardProps {
  onNewProject: () => void;
  onOpenProject: (id: string) => void;
  onCompare: () => void;
  onSignOut: () => void;
}

export function Dashboard({
  onNewProject,
  onOpenProject,
  onCompare,
  onSignOut,
}: DashboardProps) {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProjects()
      .then((data) => {
        setProjects(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const handleNew = useCallback(() => {
    onNewProject();
  }, [onNewProject]);

  return (
    <div className="min-h-screen bg-cream-100 text-plum font-body">
      <a href="#dashboard-main" className="skip-link">
        Skip to projects
      </a>

      {/* Header */}
      <header className="sticky top-0 z-40 bg-cream-100/85 backdrop-blur-md border-b border-cream-300">
        <div className="max-w-workspace mx-auto px-6 h-16 flex items-center justify-between">
          <Logo />
          <div className="flex items-center gap-3">
            <button onClick={handleNew} className="btn btn-primary text-sm">
              <Plus size={16} aria-hidden="true" />
              New project
            </button>
            <button onClick={onSignOut} className="btn btn-ghost text-sm text-plum-light">
              <LogOut size={16} aria-hidden="true" />
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main id="dashboard-main" className="max-w-workspace mx-auto px-6 py-10">
        <div className="mb-8">
          <h1 className="font-display font-extrabold text-3xl mb-1">
            Welcome back{user?.email ? '' : ''}
          </h1>
          <p className="text-plum-light">
            {projects.length === 0
              ? "Let's design your first space."
              : `${projects.length} project${projects.length === 1 ? '' : 's'}`}
          </p>
        </div>

        {error && (
          <div className="card p-4 mb-6 bg-error-light text-error text-sm font-medium" role="alert">
            {error}
          </div>
        )}

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card p-6 h-64">
                <div className="skeleton h-4 w-24 mb-4" />
                <div className="skeleton h-32 w-full mb-4" />
                <div className="skeleton h-4 w-32" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* New project card */}
            <button
              onClick={handleNew}
              className="card p-6 flex flex-col items-center justify-center min-h-[260px] border-2 border-dashed border-cream-400 hover:border-sage-400 hover:bg-sage-100/30 transition-all group"
            >
              <div className="w-14 h-14 rounded-2xl bg-sage-200 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Plus size={26} className="text-plum" aria-hidden="true" />
              </div>
              <p className="font-display font-bold text-lg mb-1">
                New project
              </p>
              <p className="text-sm text-plum-light text-center">
                Start designing a new space
              </p>
            </button>

            {/* Project cards */}
            {projects.map((project) => (
              <button
                key={project.id}
                onClick={() => onOpenProject(project.id)}
                className="card overflow-hidden hover:shadow-elevated transition-all text-left group"
              >
                {/* Room preview */}
                <ProjectPreview project={project} />

                {/* Info */}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="min-w-0">
                      <h3 className="font-display font-bold text-base truncate">
                        {project.title}
                      </h3>
                      <p className="text-xs text-plum-light">
                        {project.room_type}
                      </p>
                    </div>
                    <span
                      className={`text-2xs px-2 py-0.5 rounded-full font-bold flex-shrink-0 ${
                        project.status === 'active'
                          ? 'bg-sage-200 text-sage-700'
                          : project.status === 'draft'
                            ? 'bg-lavender-200 text-plum'
                            : 'bg-cream-300 text-plum-light'
                      }`}
                    >
                      {project.status}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mb-3">
                    <span className="text-2xs px-2 py-0.5 rounded-full bg-lavender-100 text-plum-light font-bold">
                      {project.mood}
                    </span>
                    <span className="text-2xs px-2 py-0.5 rounded-full bg-lavender-100 text-plum-light font-bold">
                      {project.budget_cents === 0
                        ? 'Rearrange'
                        : formatCurrency(project.budget_cents)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-plum-light inline-flex items-center gap-1">
                      <Clock size={12} aria-hidden="true" />
                      {formatDate(project.updated_at)}
                    </span>
                    <span className="text-xs font-bold text-sage-700 inline-flex items-center gap-0.5 group-hover:gap-1.5 transition-all">
                      Open
                      <ArrowRight size={12} aria-hidden="true" />
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function ProjectPreview({ project }: { project: Project }) {
  const [imageFailed, setImageFailed] = useState(false);

  if (!project.photo_url || imageFailed) {
    return (
      <div className="aspect-[16/10] overflow-hidden bg-cream-200">
        <RoomRender
          mood={project.mood ?? 'Cozy'}
          showPins={false}
          width={400}
          height={250}
          className="w-full h-full"
        />
      </div>
    );
  }

  return (
    <div className="aspect-[16/10] overflow-hidden bg-cream-200">
      <img
        src={project.photo_url}
        alt={`Uploaded photo of ${project.room_type.toLowerCase()}`}
        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        onError={() => setImageFailed(true)}
      />
    </div>
  );
}
