import { useState, useEffect, type FormEvent } from 'react';
import { ArrowLeft, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useAuth } from '@/lib/auth';

interface AuthPageProps {
  mode: 'signin' | 'signup';
  onBack: () => void;
  onSuccess: () => void;
  onToggleMode: () => void;
}

export function AuthPage({ mode, onBack, onSuccess, onToggleMode }: AuthPageProps) {
  const { signIn, signUp } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setError(null);
  }, [mode]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      setSubmitting(false);
      return;
    }

    const { error: authError } =
      mode === 'signin'
        ? await signIn(email, password)
        : await signUp(email, password);

    if (authError) {
      setError(authError);
      setSubmitting(false);
      return;
    }

    if (mode === 'signup') {
      // After signup, Supabase auto-signs in (email confirmation is off)
      onSuccess();
    } else {
      onSuccess();
    }
  };

  const title = mode === 'signin' ? 'Welcome back' : 'Create your account';
  const subtitle =
    mode === 'signin'
      ? 'Sign in to continue designing your space.'
      : 'Start designing your rental space today.';

  return (
    <div className="min-h-screen bg-gradient-to-b from-cream-100 to-lavender-100 flex flex-col">
      <a href="#auth-form" className="skip-link">
        Skip to sign in form
      </a>

      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <button
          onClick={onBack}
          className="self-start mb-8 btn btn-ghost text-plum-light text-sm"
        >
          <ArrowLeft size={16} aria-hidden="true" />
          Back to home
        </button>

        <div className="w-full max-w-sm">
          <div className="mb-8 text-center">
            <div className="inline-block mb-6">
              <Logo size={28} />
            </div>
            <h1 className="font-display font-extrabold text-3xl mb-2">
              {title}
            </h1>
            <p className="text-plum-light">{subtitle}</p>
          </div>

          <form
            id="auth-form"
            onSubmit={handleSubmit}
            className="card p-6 sm:p-8 space-y-4"
            noValidate
          >
            {error && (
              <div
                role="alert"
                className="flex items-start gap-2.5 p-3.5 rounded-xl bg-error-light text-error text-sm font-medium animate-slide-up"
              >
                <AlertCircle size={18} className="flex-shrink-0 mt-0.5" aria-hidden="true" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label
                htmlFor="email"
                className="block text-sm font-bold mb-1.5"
              >
                Email
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-field"
                placeholder="you@example.com"
                aria-required="true"
                disabled={submitting}
              />
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-bold mb-1.5"
              >
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete={
                    mode === 'signin' ? 'current-password' : 'new-password'
                  }
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-field pr-11"
                  placeholder="At least 6 characters"
                  aria-required="true"
                  disabled={submitting}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-plum-light hover:text-plum p-1"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? (
                    <EyeOff size={18} aria-hidden="true" />
                  ) : (
                    <Eye size={18} aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary w-full text-base py-3 h-auto"
              disabled={submitting}
            >
              {submitting
                ? 'Please wait...'
                : mode === 'signin'
                  ? 'Sign in'
                  : 'Create account'}
            </button>
          </form>

          <p className="text-center text-sm text-plum-light mt-6">
            {mode === 'signin' ? (
              <>
                New to SpaceLift?{' '}
                <button
                  onClick={onToggleMode}
                  className="font-bold text-sage-700 hover:underline"
                >
                  Create an account
                </button>
              </>
            ) : (
              <>
                Already have an account?{' '}
                <button
                  onClick={onToggleMode}
                  className="font-bold text-sage-700 hover:underline"
                >
                  Sign in
                </button>
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
