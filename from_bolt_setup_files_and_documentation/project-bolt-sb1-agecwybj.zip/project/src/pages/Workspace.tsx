import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Share,
  Download,
  Layers,
  Sun,
  Moon,
  Eye,
  Pin,
  List,
  ClipboardList,
  ChevronDown,
  X,
  Sparkles,
  LogOut,
  Home,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { RoomRender } from '@/components/RoomRender';
import { ChatPanel } from '@/components/ChatPanel';
import { ShoppingList } from '@/components/ShoppingList';
import { VersionHistory } from '@/components/VersionHistory';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import {
  fetchProject,
  fetchVersions,
  fetchItems,
  fetchMessages,
  updateItem,
  deleteItem,
  createVersion,
  setCurrentVersion,
  createMessage,
  updateProject,
  insertItems,
} from '@/lib/api';
import { generateDesign, type SwapSuggestion } from '@/lib/design';
import { formatCurrency, dollarsToCents } from '@/lib/format';
import type {
  Project,
  DesignVersion,
  DesignItem,
  ChatMessage,
  ItemCategory,
  DamageBadge,
} from '@/types';
import {
  ROOM_TYPES,
  MOOD_OPTIONS,
  DAMAGE_LEVELS,
  BUDGET_CAPS,
} from '@/types';

interface WorkspaceProps {
  projectId: string;
  onBack: () => void;
  onCompare: (projectId: string) => void;
}

type Tab = 'design' | 'shopping' | 'setup';

export function Workspace({ projectId, onBack, onCompare: _onCompare }: WorkspaceProps) {
  const { signOut } = useAuth();
  const getSessionToken = useCallback(async (): Promise<string> => {
    const { data } = await supabase.auth.getSession();
    return data.session?.access_token ?? import.meta.env.VITE_SUPABASE_ANON_KEY;
  }, []);
  const [project, setProject] = useState<Project | null>(null);
  const [versions, setVersions] = useState<DesignVersion[]>([]);
  const [currentVersion, setCurrentVersionState] = useState<DesignVersion | null>(null);
  const [items, setItems] = useState<DesignItem[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // UI state
  const [activeTab, setActiveTab] = useState<Tab>('design');
  const [evening, setEvening] = useState(false);
  const [showPins, setShowPins] = useState(true);
  const [selectedPin, setSelectedPin] = useState<number | null>(null);
  const [showVersions, setShowVersions] = useState(false);
  const [showChat, setShowChat] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [generatingImage, setGeneratingImage] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  const [genStep, setGenStep] = useState(0);
  const [viewMode, setViewMode] = useState<'after' | 'before'>('after');
  const [editingPill, setEditingPill] = useState<number | null>(null);
  const [briefChanged, setBriefChanged] = useState(false);
  const generatingRef = useRef(false);
  const imageGenAttempted = useRef(false);

  const totalCents = items.reduce(
    (sum, i) => sum + i.price_cents * (i.already_own ? 0 : 1) * i.quantity,
    0
  );
  const overBudget =
    project && project.budget_cents > 0 && totalCents > project.budget_cents;

  // Load project data
  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        setLoading(true);
        const proj = await fetchProject(projectId);
        if (!proj || cancelled) return;
        setProject(proj);

        const [vers, msgs] = await Promise.all([
          fetchVersions(projectId),
          fetchMessages(projectId),
        ]);
        if (cancelled) return;

        setVersions(vers);
        setMessages(msgs);

        const current = vers.find((v) => v.is_current) ?? vers[vers.length - 1];
        if (current) {
          setCurrentVersionState(current);
          const its = await fetchItems(current.id);
          if (!cancelled) setItems(its);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to load project');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [projectId]);

  // Generating animation
  useEffect(() => {
    if (!generating || generatingRef.current) return;
    generatingRef.current = true;
    const steps = ['Analyzing your room...', 'Picking items...', 'Checking lease rules...', 'Placing them...', 'Checking budget...'];
    let i = 0;
    const interval = setInterval(() => {
      i++;
      if (i >= steps.length) {
        clearInterval(interval);
        setGenerating(false);
        setGenStep(0);
        generatingRef.current = false;
      } else {
        setGenStep(i);
      }
    }, 800);
    return () => clearInterval(interval);
  }, [generating]);

  const generateDesignImage = useCallback(
    async (versionId: string, userMessage?: string) => {
      if (!project) return;
      setGeneratingImage(true);
      setImageError(null);
      try {
        const token = await getSessionToken();
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-design`;
        const resp = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            mode: 'generate-design',
            project_id: project.id,
            photo_url: project.photo_url,
            version_id: versionId,
            room_type: project.room_type,
            occasion: project.occasion,
            budget_cents: project.budget_cents,
            mood: project.mood,
            damage_level: project.damage_level,
            lighting_recipe: project.lighting_recipe,
            wall_width_ft: project.wall_width_ft,
            user_message: userMessage,
          }),
        });

        if (!resp.ok) {
          const errBody = await resp.text().catch(() => '');
          throw new Error(`Image generation failed (${resp.status}): ${errBody.slice(0, 200)}`);
        }

        const data = await resp.json();
        if (data.error) {
          throw new Error(data.error);
        }

        if (!data.design_image_url) {
          throw new Error('No image URL returned from the server.');
        }

        if (data.design_image_url) {
          setCurrentVersionState((prev) =>
            prev ? { ...prev, design_image_url: data.design_image_url } : prev
          );
          setVersions((prev) =>
            prev.map((v) =>
              v.id === versionId
                ? { ...v, design_image_url: data.design_image_url }
                : v
            )
          );
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unknown error';
        console.error('Image generation error:', msg);
        setImageError(msg);
      } finally {
        setGeneratingImage(false);
      }
    },
    [project, getSessionToken]
  );

  // Auto-generate design image on initial load if no image exists yet
  useEffect(() => {
    if (!project || !currentVersion || loading) return;
    if (currentVersion.design_image_url) return;
    if (generatingImage) return;
    if (imageGenAttempted.current) return;
    imageGenAttempted.current = true;
    generateDesignImage(currentVersion.id);
  }, [project, currentVersion, loading, generatingImage, generateDesignImage]);

  const handleSend = useCallback(
    async (content: string) => {
      if (!project) return;

      const userMsg = await createMessage(project.id, {
        role: 'user',
        content,
      });
      setMessages((prev) => [...prev, userMsg]);

      setIsTyping(true);

      try {
        // Call the AI edge function
        const token = await getSessionToken();
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-design`;
        const resp = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            project_id: project.id,
            user_message: content,
            project_context: {
              title: project.title,
              room_type: project.room_type,
              occasion: project.occasion,
              budget_cents: project.budget_cents,
              budget_cap: project.budget_cap,
              wall_width_ft: project.wall_width_ft,
              damage_level: project.damage_level,
              mood: project.mood,
              lighting_recipe: project.lighting_recipe,
            },
            current_items: items.map((i) => ({
              pin_number: i.pin_number,
              name: i.name,
              store: i.store,
              price_cents: i.price_cents,
              quantity: i.quantity,
              category: i.category,
              damage_badge: i.damage_badge,
            })),
            history: messages.map((m) => ({ role: m.role, content: m.content })),
          }),
        });

        if (!resp.ok) {
          throw new Error(`AI request failed (${resp.status})`);
        }

        const data = await resp.json();

        if (data.error) {
          throw new Error(data.error);
        }

        const aiMsg = await createMessage(project.id, {
          role: 'assistant',
          content: data.message || 'I processed your request.',
          action_data: data.action ?? null,
        });
        setMessages((prev) => [...prev, aiMsg]);
        setIsTyping(false);

        // Handle actions from the AI response
        const action = data.action;
        if (action?.type === 'swap' && action.pin) {
          const pin = action.pin as number;
          const item = items.find((i) => i.pin_number === pin);
          if (item) {
            const updates: Partial<typeof item> = {};
            if (action.property === 'wire_color' && action.value) {
              updates.wire_color = action.value as string;
            }
            if (action.name) updates.name = action.name as string;
            if (action.price !== undefined) updates.price_cents = action.price as number;
            if (action.store) updates.store = action.store as string;
            if (action.wire_color) updates.wire_color = action.wire_color;
            if (Object.keys(updates).length > 0) {
              const updated = await updateItem(item.id, updates);
              setItems((prev) => prev.map((i) => (i.id === updated.id ? updated : i)));
            }
          }
        }

        if (action?.type === 'view' && action.view === 'evening') {
          setEvening(true);
        }
        if (action?.type === 'view' && action.view === 'day') {
          setEvening(false);
        }

        // Regenerate the design image when a redesign is requested
        if (action?.type === 'redesign' && currentVersion) {
          await generateDesignImage(currentVersion.id, content);
        }

        if (action?.type === 'remove-item' && action.pin) {
          const item = items.find((i) => i.pin_number === action.pin);
          if (item) {
            await deleteItem(item.id);
            setItems((prev) => prev.filter((i) => i.id !== item.id));
          }
        }

        if (action?.type === 'add-item' && data.new_items) {
          const newItems = data.new_items as Array<{
            name: string;
            store: string;
            price_cents: number;
            quantity: number;
            category: string;
            damage_badge: string;
            wire_color?: string;
          }>;
          if (currentVersion) {
            const nextPin = Math.max(...items.map((i) => i.pin_number), 0) + 1;
            const rows = newItems.map((item, idx) => ({
              ...item,
              pin_number: nextPin + idx,
              category: item.category as ItemCategory,
              damage_badge: item.damage_badge as DamageBadge,
              wire_color: item.wire_color ?? null,
              locked: false,
              already_own: false,
              notes: null,
              sort_order: items.length + idx,
            }));
            await insertItems(currentVersion.id, rows);
            const refreshed = await fetchItems(currentVersion.id);
            setItems(refreshed);
          }
        }
      } catch (err) {
        setIsTyping(false);
        const errMsg = await createMessage(project.id, {
          role: 'assistant',
          content: `Sorry, I had trouble processing that. ${err instanceof Error ? err.message : 'Please try again.'}`,
        });
        setMessages((prev) => [...prev, errMsg]);
      }
    },
    [project, items, totalCents, messages, currentVersion, generateDesignImage, getSessionToken]
  );

  const handleLock = useCallback(async (id: string) => {
    const item = items.find((i) => i.id === id);
    if (!item) return;
    const updated = await updateItem(id, { locked: !item.locked });
    setItems((prev) => prev.map((i) => (i.id === updated.id ? updated : i)));
  }, [items]);

  const handleRemove = useCallback(async (id: string) => {
    await deleteItem(id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const handleOwn = useCallback(async (id: string) => {
    const item = items.find((i) => i.id === id);
    if (!item) return;
    const updated = await updateItem(id, { already_own: !item.already_own });
    setItems((prev) => prev.map((i) => (i.id === updated.id ? updated : i)));
  }, [items]);

  const handleSwap = useCallback(
    async (id: string, suggestion: SwapSuggestion) => {
      const updated = await updateItem(id, {
        name: suggestion.name,
        store: suggestion.store,
        price_cents: suggestion.priceCents,
        wire_color: suggestion.wireColor ?? null,
      });
      setItems((prev) => prev.map((i) => (i.id === updated.id ? updated : i)));
    },
    []
  );

  const handleQtyChange = useCallback(
    async (id: string, qty: number) => {
      const updated = await updateItem(id, { quantity: qty });
      setItems((prev) => prev.map((i) => (i.id === updated.id ? updated : i)));
    },
    []
  );

  const handleRestore = useCallback(
    async (versionId: string) => {
      if (!project) return;
      await setCurrentVersion(project.id, versionId);
      const vers = await fetchVersions(project.id);
      setVersions(vers);
      const current = vers.find((v) => v.id === versionId);
      if (current) {
        setCurrentVersionState(current);
        const its = await fetchItems(current.id);
        setItems(its);
      }
      setShowVersions(false);
    },
    [project]
  );

  const handleNewVersion = useCallback(
    async (label: string, summary: string) => {
      if (!project) return;
      const newVersionNum = Math.max(...versions.map((v) => v.version_number), 0) + 1;
      const design = generateDesign(project);
      const version = await createVersion(project.id, {
        version_number: newVersionNum,
        label,
        total_cents: design.totalCents,
        summary,
        room_config: design.roomConfig,
      });
      setVersions((prev) => [...prev, version]);
      setCurrentVersionState(version);
      setShowVersions(false);
    },
    [project, versions]
  );

  const handleSignOut = useCallback(async () => {
    await signOut();
    onBack();
  }, [signOut, onBack]);

  if (loading) {
    return (
      <div className="min-h-screen bg-cream-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 mx-auto mb-4 rounded-full border-4 border-cream-300 border-t-sage-400 animate-spin" />
          <p className="font-bold text-plum-light">Loading your design...</p>
        </div>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen bg-cream-100 flex items-center justify-center p-6">
        <div className="text-center max-w-sm">
          <X size={32} className="mx-auto mb-3 text-error" aria-hidden="true" />
          <p className="font-bold text-plum mb-2">Could not load project</p>
          <p className="text-sm text-plum-light mb-4">
            {error ?? 'The project may not exist or you may not have access.'}
          </p>
          <button onClick={onBack} className="btn btn-primary">
            Go back
          </button>
        </div>
      </div>
    );
  }

  const briefPills: { label: string }[] = [
    { label: project.occasion ?? 'Everyday' },
    { label: project.room_type },
    {
      label:
        project.budget_cents === 0
          ? 'Rearrange · $0'
          : `${formatCurrency(project.budget_cents)} · ${
              project.budget_cap === 'hard' ? 'Hard cap' : project.budget_cap === 'soft' ? 'Soft cap' : 'No limit'
            }`,
    },
    { label: project.mood ?? 'Cozy' },
    {
      label:
        project.damage_level === 'none'
          ? 'No damage'
          : project.damage_level === 'minor'
            ? 'Minor OK'
            : 'Anything goes',
    },
    { label: `Wall ${project.wall_width_ft} ft` },
  ];

  return (
    <div className="h-screen flex flex-col bg-cream-100 text-plum font-body overflow-hidden">
      <a href="#workspace-main" className="skip-link">
        Skip to workspace
      </a>

      {/* Header */}
      <header className="flex-shrink-0 h-15 flex items-center gap-3 px-4 lg:px-5 border-b border-cream-300 bg-cream-50" style={{ height: 60 }}>
        <Logo size={20} />
        <div className="w-px h-6 bg-cream-300" />
        <button
          className="flex items-center gap-2 h-9 px-2.5 rounded-xl border border-dashed border-cream-400 bg-transparent font-bold text-sm hover:bg-lavender-100 transition-colors"
          aria-label="Rename project"
        >
          {project.title} · {project.room_type.toLowerCase()}
        </button>
        {currentVersion && (
          <button
            onClick={() => setShowVersions(!showVersions)}
            className="h-8 px-3 rounded-full bg-lavender-100 border border-cream-300 font-extrabold text-xs flex items-center gap-1.5 hover:bg-lavender-200 transition-colors"
            aria-label="Version history"
          >
            <Layers size={13} aria-hidden="true" />
            v{currentVersion.version_number}
          </button>
        )}
        <div className="flex-grow" />
        <button
          onClick={() => _onCompare(project.id)}
          className="hidden sm:flex btn btn-secondary text-sm h-9"
        >
          <Layers size={15} aria-hidden="true" />
          Compare 3 ways
        </button>
        <button className="hidden sm:flex btn btn-secondary text-sm h-9">
          <Share size={15} aria-hidden="true" />
          Share
        </button>
        <button className="btn btn-primary text-sm h-9">
          <Download size={15} aria-hidden="true" />
          Export
        </button>
        <div className="w-px h-6 bg-cream-300" />
        <button
          onClick={onBack}
          className="btn btn-ghost h-9 w-9 p-0"
          aria-label="Back to projects"
        >
          <Home size={16} aria-hidden="true" />
        </button>
        <button
          onClick={handleSignOut}
          className="btn btn-ghost h-9 w-9 p-0"
          aria-label="Sign out"
        >
          <LogOut size={16} aria-hidden="true" />
        </button>
      </header>

      {/* Brief bar */}
      <div className="flex-shrink-0 border-b border-cream-300 bg-cream-50">
        <div className="flex items-center gap-4 px-5 py-3 overflow-x-auto">
          <span className="text-xs font-extrabold uppercase tracking-wider text-plum-light whitespace-nowrap">
            Project brief
          </span>
          <div className="flex flex-wrap gap-2 flex-grow">
            {briefPills.map((pill, i) => (
              <button
                key={i}
                onClick={() => setEditingPill(editingPill === i ? null : i)}
                className={`pill h-8 text-[13px] ${
                  editingPill === i ? 'pill-active' : 'pill-default'
                }`}
                aria-expanded={editingPill === i}
              >
                {pill.label}
                <ChevronDown size={12} className="opacity-50" aria-hidden="true" />
              </button>
            ))}
          </div>
          <span className="text-xs text-plum-light whitespace-nowrap hidden lg:block">
            Tap a pill to change it
          </span>
          {briefChanged && currentVersion && (
            <button
              onClick={() => {
                setBriefChanged(false);
                generateDesignImage(currentVersion.id);
              }}
              disabled={generatingImage}
              className="btn btn-primary h-8 text-[13px] whitespace-nowrap ml-2"
            >
              <Sparkles size={14} aria-hidden="true" />
              {generatingImage ? 'Generating...' : 'Regenerate design'}
            </button>
          )}
        </div>
        {editingPill !== null && (
          <BriefPillEditor
            index={editingPill}
            project={project}
            onSave={async (updates) => {
              const updated = await updateProject(project.id, updates);
              setProject(updated);
              setEditingPill(null);
              setBriefChanged(true);
            }}
            onClose={() => setEditingPill(null)}
          />
        )}
      </div>

      {/* Generating overlay */}
      {generating && (
        <div className="absolute inset-0 z-40 bg-cream-100/90 backdrop-blur-sm flex items-center justify-center" role="status" aria-live="polite">
          <div className="text-center max-w-sm">
            <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-sage-200 flex items-center justify-center animate-glow-pulse">
              <Sparkles size={28} className="text-plum" aria-hidden="true" />
            </div>
            <h2 className="font-display font-extrabold text-xl mb-2">
              Designing v{versions.length + 1}
            </h2>
            <p className="text-sm text-plum-light mb-4" aria-live="polite">
              {['Analyzing your room...', 'Picking items...', 'Checking lease rules...', 'Placing them...', 'Checking budget...'][genStep]}
            </p>
            <div className="h-1.5 bg-cream-300 rounded-full overflow-hidden max-w-xs mx-auto">
              <div
                className="h-full bg-sage-400 transition-all duration-700"
                style={{ width: `${((genStep + 1) / 5) * 100}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Main content */}
      <div id="workspace-main" className="flex-1 flex overflow-hidden">
        {/* Left: Chat */}
        {showChat && (
          <aside className="w-80 lg:w-96 flex-shrink-0 border-r border-cream-300 hidden lg:block">
            <ChatPanel
              messages={messages}
              projectName={project.title}
              budgetCents={project.budget_cents}
              totalCents={totalCents}
              onSend={handleSend}
              isTyping={isTyping}
            />
          </aside>
        )}

        {/* Center: Room render */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Design summary banner */}
          {currentVersion && (
            <div className="flex-shrink-0 px-5 py-3 bg-lavender-100 border-b border-cream-300">
              <p className="text-sm text-plum leading-relaxed">
                {currentVersion.summary || 'Your design is ready.'}
              </p>
              <p className="text-xs text-plum-light mt-1 font-bold">
                v{currentVersion.version_number} · {currentVersion.label} ·{' '}
                {formatCurrency(totalCents)}
                {project.budget_cents > 0 && (
                  <> of {formatCurrency(project.budget_cents)}</>
                )}
              </p>
            </div>
          )}

          {/* Room render */}
          <div className="flex-1 min-h-0 overflow-hidden flex items-center justify-center p-4 lg:p-6 bg-gradient-to-b from-cream-100 to-lavender-100">
            <div className="w-full max-w-3xl max-h-full flex flex-col min-h-0">
              {/* Before / After toggle */}
              {currentVersion?.design_image_url && project.photo_url && (
                <div className="flex justify-center mb-3">
                  <div className="inline-flex bg-cream-200 rounded-xl p-1 shadow-soft" role="group" aria-label="Before or after view">
                    <button
                      onClick={() => setViewMode('before')}
                      className={`px-5 py-2 rounded-lg text-sm font-bold transition-all ${
                        viewMode === 'before' ? 'bg-cream-50 text-plum shadow-soft' : 'text-plum-light hover:text-plum'
                      }`
                    }
                      aria-pressed={viewMode === 'before'}
                    >
                      Before
                    </button>
                    <button
                      onClick={() => setViewMode('after')}
                      className={`px-5 py-2 rounded-lg text-sm font-bold transition-all ${
                        viewMode === 'after' ? 'bg-cream-50 text-plum shadow-soft' : 'text-plum-light hover:text-plum'
                      }`
                    }
                      aria-pressed={viewMode === 'after'}
                    >
                      After
                    </button>
                  </div>
                </div>
              )}
              <div className="card flex-1 min-h-0 overflow-hidden shadow-card relative">
                {currentVersion?.design_image_url && viewMode === 'before' && project.photo_url ? (
                  <div className="relative h-full min-h-0 flex items-center justify-center">
                    <img
                      src={project.photo_url}
                      alt="Your original room before redesign"
                      className="max-w-full max-h-full w-auto h-auto object-contain block"
                    />
                  </div>
                ) : currentVersion?.design_image_url && viewMode === 'after' ? (
                  <div className="relative h-full min-h-0 flex items-center justify-center">
                    <img
                      src={currentVersion.design_image_url}
                      alt={`AI-designed ${project.room_type.toLowerCase()} in ${project.mood?.toLowerCase() ?? 'cozy'} mood`}
                      className="max-w-full max-h-full w-auto h-auto object-contain block"
                    />
                    {showPins && (
                      <div className="absolute inset-0">
                        {items.map((item) => (
                          <button
                            key={item.id}
                            onClick={() => setSelectedPin(item.pin_number === selectedPin ? null : item.pin_number)}
                            className={`absolute w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold transition-all ${
                              selectedPin === item.pin_number
                                ? 'bg-plum text-cream-50 scale-125 shadow-elevated'
                                : 'bg-cream-50/90 text-plum hover:bg-plum hover:text-cream-50 shadow-soft'
                            }`}
                            style={{
                              left: `${15 + (item.pin_number % 5) * 18}%`,
                              top: `${20 + Math.floor(item.pin_number / 5) * 25}%`,
                            }}
                            aria-label={`Pin ${item.pin_number}: ${item.name}`}
                          >
                            {item.pin_number}
                          </button>
                        ))}
                      </div>
                    )}
                    {evening && (
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-plum/20 to-plum/40 pointer-events-none" />
                    )}
                  </div>
                ) : generatingImage ? (
                  <div className="flex flex-col items-center justify-center py-20 px-6">
                    <div className="w-16 h-16 mb-4 rounded-2xl bg-sage-200 flex items-center justify-center animate-glow-pulse">
                      <Sparkles size={28} className="text-plum" aria-hidden="true" />
                    </div>
                    <p className="font-display font-extrabold text-lg text-plum mb-1">
                      Generating your design...
                    </p>
                    <p className="text-sm text-plum-light text-center max-w-xs">
                      I'm creating a personalized room design based on your photo and preferences.
                    </p>
                  </div>
                ) : (
                  <RoomRender
                    mood={project.mood ?? 'Cozy'}
                    evening={evening}
                    showPins={showPins}
                    selectedPin={selectedPin ?? undefined}
                    onPinClick={(pin) => setSelectedPin(pin === selectedPin ? null : pin)}
                    wallWidth={project.wall_width_ft ?? 12}
                    className="w-full"
                    width={960}
                    height={600}
                  />
                )}
              </div>
              {!currentVersion?.design_image_url && !generatingImage && imageError && (
                <div className="mt-3 p-3 card flex items-start gap-3 bg-error-light border border-error/30" role="alert">
                  <Sparkles size={18} className="text-error flex-shrink-0 mt-0.5" aria-hidden="true" />
                  <div className="flex-1">
                    <p className="text-xs font-bold text-error mb-1">
                      Design image could not be generated
                    </p>
                    <p className="text-xs text-error/80 mb-2">
                      {imageError}
                    </p>
                    <button
                      onClick={() => {
                        setImageError(null);
                        if (currentVersion) {
                          imageGenAttempted.current = false;
                          generateDesignImage(currentVersion.id);
                        }
                      }}
                      className="text-xs font-bold text-error underline hover:no-underline"
                    >
                      Try again
                    </button>
                  </div>
                </div>
              )}
              {!currentVersion?.design_image_url && !generatingImage && !imageError && (
                <div className="mt-3 p-3 card flex items-center gap-3 bg-lavender-100">
                  <Sparkles size={18} className="text-plum flex-shrink-0" aria-hidden="true" />
                  <p className="text-xs text-plum-light">
                    Showing a layout preview of your design.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Bottom controls */}
          <div className="flex-shrink-0 flex items-center gap-3 px-5 py-3 border-t border-cream-300 bg-cream-50">
            {/* Day/Evening toggle */}
            <div className="flex bg-cream-200 rounded-xl p-1" role="group" aria-label="View mode">
              <button
                onClick={() => setEvening(false)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${
                  !evening ? 'bg-cream-50 text-plum shadow-soft' : 'text-plum-light'
                }`}
                aria-pressed={!evening}
              >
                <Sun size={14} aria-hidden="true" />
                Day
              </button>
              <button
                onClick={() => setEvening(true)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${
                  evening ? 'bg-cream-50 text-plum shadow-soft' : 'text-plum-light'
                }`}
                aria-pressed={evening}
              >
                <Moon size={14} aria-hidden="true" />
                Evening
              </button>
            </div>

            {/* Pins toggle */}
            <button
              onClick={() => setShowPins(!showPins)}
              className={`btn text-sm h-9 ${showPins ? 'btn-sage' : 'btn-secondary'}`}
              aria-pressed={showPins}
            >
              <Pin size={14} aria-hidden="true" />
              {showPins ? 'Hide pins' : 'Show pins'}
            </button>

            {/* Budget tracker */}
            {project.budget_cents > 0 && (
              <div className="flex items-center gap-2 ml-auto">
                <div className="text-right">
                  <p
                    className={`font-display font-extrabold text-sm ${
                      overBudget ? 'text-error' : 'text-plum'
                    }`}
                  >
                    {formatCurrency(totalCents)} of {formatCurrency(project.budget_cents)}
                  </p>
                  <p className="text-xs text-plum-light">
                    {overBudget
                      ? `${formatCurrency(totalCents - project.budget_cents)} over`
                      : `${formatCurrency(project.budget_cents - totalCents)} left`}
                  </p>
                </div>
                <div className="w-24 h-2 bg-cream-300 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${
                      overBudget ? 'bg-error' : 'bg-sage-400'
                    }`}
                    style={{
                      width: `${Math.min(100, (totalCents / project.budget_cents) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            )}

            {/* Chat toggle (mobile) */}
            <button
              onClick={() => setShowChat(!showChat)}
              className="btn btn-ghost h-9 w-9 p-0 lg:hidden"
              aria-label="Toggle chat"
              aria-pressed={showChat}
            >
              <Sparkles size={16} aria-hidden="true" />
            </button>
          </div>

          {/* Tabs (mobile) */}
          <div className="flex-shrink-0 flex border-t border-cream-300 bg-cream-50 lg:hidden" role="tablist" aria-label="Workspace views">
            {([
              { id: 'design' as const, label: 'Design', icon: Eye },
              { id: 'shopping' as const, label: 'Shopping list', icon: List },
              { id: 'setup' as const, label: 'Setup plan', icon: ClipboardList },
            ]).map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-bold transition-colors ${
                    activeTab === tab.id
                      ? 'text-plum border-b-2 border-sage-400'
                      : 'text-plum-light'
                  }`}
                  aria-selected={activeTab === tab.id}
                  role="tab"
                  aria-controls={`tabpanel-${tab.id}`}
                  id={`tab-${tab.id}`}
                >
                  <Icon size={15} aria-hidden="true" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </main>

        {/* Right: Side panel (versions / shopping / setup) */}
        <aside className="w-80 lg:w-96 flex-shrink-0 border-l border-cream-300 hidden lg:flex flex-col">
          {showVersions ? (
            <VersionHistory
              versions={versions}
              currentVersionId={currentVersion?.id ?? null}
              onRestore={handleRestore}
              onCompare={() => {}}
              onClose={() => setShowVersions(false)}
            />
          ) : (
            <>
              {/* Tab buttons */}
              <div className="flex border-b border-cream-300">
                {([
                  { id: 'design' as const, label: 'Shopping list', icon: List },
                  { id: 'shopping' as const, label: 'Setup plan', icon: ClipboardList },
                ]).map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id === 'design' ? 'shopping' : 'setup')}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-bold transition-colors ${
                        (tab.id === 'design' && activeTab === 'shopping') ||
                        (tab.id === 'shopping' && activeTab === 'setup')
                          ? 'text-plum border-b-2 border-sage-400'
                          : 'text-plum-light'
                      }`}
                      aria-selected={
                        (tab.id === 'design' && activeTab === 'shopping') ||
                        (tab.id === 'shopping' && activeTab === 'setup')
                      }
                      role="tab"
                    >
                      <Icon size={15} aria-hidden="true" />
                      {tab.label}
                    </button>
                  );
                })}
                <button
                  onClick={() => setShowVersions(true)}
                  className="px-3 flex items-center justify-center border-l border-cream-300 text-plum-light hover:text-plum"
                  aria-label="Version history"
                >
                  <Layers size={16} aria-hidden="true" />
                </button>
              </div>

              {activeTab === 'shopping' ? (
                <ShoppingList
                  items={items}
                  budgetCents={project.budget_cents}
                  totalCents={totalCents}
                  onLock={handleLock}
                  onRemove={handleRemove}
                  onOwn={handleOwn}
                  onSwap={handleSwap}
                  onQtyChange={handleQtyChange}
                />
              ) : activeTab === 'setup' ? (
                <SetupPlan items={items} budgetCents={project.budget_cents} />
              ) : null}
            </>
          )}
        </aside>

        {/* Mobile shopping list */}
        {activeTab === 'shopping' && (
          <div
            className="lg:hidden fixed inset-0 top-0 z-50 bg-cream-50 animate-slide-right"
            role="dialog"
            aria-modal="true"
            aria-label="Shopping list"
            onKeyDown={(e) => {
              if (e.key === 'Escape') setActiveTab('design');
            }}
          >
            <div className="flex items-center justify-between p-3 border-b border-cream-300">
              <h2 className="font-bold">Shopping list</h2>
              <button
                onClick={() => setActiveTab('design')}
                className="btn btn-ghost h-8 w-8 p-0"
                aria-label="Close shopping list"
              >
                <X size={18} aria-hidden="true" />
              </button>
            </div>
            <div className="h-[calc(100%-56px)]" id="tabpanel-shopping" role="tabpanel">
              <ShoppingList
                items={items}
                budgetCents={project.budget_cents}
                totalCents={totalCents}
                onLock={handleLock}
                onRemove={handleRemove}
                onOwn={handleOwn}
                onSwap={handleSwap}
                onQtyChange={handleQtyChange}
              />
            </div>
          </div>
        )}
      </div>

      {/* Selected pin detail (floating) */}
      {selectedPin !== null && (
        <PinDetail
          item={items.find((i) => i.pin_number === selectedPin)}
          onClose={() => setSelectedPin(null)}
        />
      )}
      {selectedPin !== null && (
        <EscapeHandler onEscape={() => setSelectedPin(null)} />
      )}
    </div>
  );
}

function PinDetail({
  item,
  onClose,
}: {
  item: DesignItem | undefined;
  onClose: () => void;
}) {
  if (!item) return null;
  return (
    <div
      className="absolute bottom-20 left-1/2 -translate-x-1/2 z-30 card shadow-elevated p-4 w-80 animate-slide-up"
      role="dialog"
      aria-label={`Pin ${item.pin_number} details`}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-full bg-plum text-cream-50 flex items-center justify-center text-sm font-extrabold">
            {item.pin_number}
          </span>
          <div>
            <p className="font-bold text-sm">{item.name}</p>
            <p className="text-xs text-plum-light">
              {item.store} · {formatCurrency(item.price_cents)}
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="btn btn-ghost h-7 w-7 p-0"
          aria-label="Close pin detail"
        >
          <X size={14} aria-hidden="true" />
        </button>
      </div>
      <p className="text-xs text-plum-light mb-3">
        Press Esc to clear
      </p>
      <div className="flex gap-2">
        <button className="btn btn-secondary text-xs flex-1 h-8">
          Swap
        </button>
        <button className="btn btn-secondary text-xs flex-1 h-8">
          Lock
        </button>
      </div>
    </div>
  );
}

function SetupPlan({ items, budgetCents }: { items: DesignItem[]; budgetCents: number }) {
  const totalTime = items.length * 3;
  const categories = items.reduce((acc, i) => {
    acc[i.category] = (acc[i.category] ?? 0) + i.price_cents * i.quantity;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      <div className="card p-4">
        <h3 className="font-bold text-sm mb-3">Setup plan</h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-plum-light">Total time</span>
            <span className="text-sm font-bold">~{totalTime} min</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-plum-light">Items to place</span>
            <span className="text-sm font-bold">{items.length}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-plum-light">Budget</span>
            <span className="text-sm font-bold">
              {budgetCents === 0 ? 'Rearrange only' : formatCurrency(budgetCents)}
            </span>
          </div>
        </div>
      </div>

      <div className="card p-4">
        <h3 className="font-bold text-sm mb-3">Spending by category</h3>
        <div className="space-y-2.5">
          {Object.entries(categories).map(([cat, amount]) => {
            const pct = totalAmount(categories) > 0 ? (amount / totalAmount(categories)) * 100 : 0;
            return (
              <div key={cat}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-bold text-plum">{cat}</span>
                  <span className="text-plum-light">{Math.round(pct)}%</span>
                </div>
                <div className="h-1.5 bg-cream-300 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-sage-400 transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="card p-4">
        <h3 className="font-bold text-sm mb-3">Steps</h3>
        <div className="space-y-2">
          {items.map((item, i) => (
            <div key={item.id} className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-lavender-200 text-plum flex items-center justify-center text-xs font-extrabold flex-shrink-0 mt-0.5">
                {i + 1}
              </span>
              <div>
                <p className="text-sm font-bold text-plum">{item.name}</p>
                <p className="text-xs text-plum-light">
                  {item.already_own ? 'You own this · just place it' : `Buy at ${item.store}`}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function totalAmount(cats: Record<string, number>): number {
  return Object.values(cats).reduce((s, v) => s + v, 0);
}

function BriefPillEditor({
  index,
  project,
  onSave,
  onClose,
}: {
  index: number;
  project: Project;
  onSave: (updates: Partial<Project>) => void;
  onClose: () => void;
}) {
  const [occasion, setOccasion] = useState(project.occasion ?? 'Everyday');
  const [budgetInput, setBudgetInput] = useState(
    String(Math.round(project.budget_cents / 100))
  );
  const [wallWidth, setWallWidth] = useState(String(project.wall_width_ft ?? 12));

  const labels = ['Occasion', 'Room type', 'Budget', 'Mood', 'Lease rules', 'Wall width'];
  const snapPoints = [0, 25, 50, 75, 100, 150, 200, 300, 500];

  return (
    <>
      <div className="fixed inset-0 z-20" onClick={onClose} />
      <div className="relative z-30 px-5 pb-4 animate-slide-up">
        <div className="flex items-center justify-between mb-3 mt-1">
          <p className="text-sm font-extrabold text-plum">Edit {labels[index]}</p>
          <button
            onClick={onClose}
            className="btn btn-ghost h-7 w-7 p-0"
            aria-label="Close editor"
          >
            <X size={14} aria-hidden="true" />
          </button>
        </div>

        {index === 0 && (
          <div className="flex gap-2">
            <input
              type="text"
              value={occasion}
              onChange={(e) => setOccasion(e.target.value)}
              className="input-field flex-1 h-9"
              placeholder="Everyday, Birthday party, Housewarming..."
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') onSave({ occasion });
              }}
            />
            <button
              onClick={() => onSave({ occasion })}
              className="btn btn-primary h-9"
            >
              Save
            </button>
          </div>
        )}

        {index === 1 && (
          <div className="flex flex-wrap gap-2">
            {ROOM_TYPES.map((room) => (
              <button
                key={room}
                onClick={() => onSave({ room_type: room })}
                className={`pill ${
                  project.room_type === room ? 'pill-active' : 'pill-default'
                }`}
              >
                {room}
              </button>
            ))}
          </div>
        )}

        {index === 2 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-lg font-extrabold text-plum">$</span>
              <input
                type="number"
                min="0"
                step="5"
                value={budgetInput}
                onChange={(e) => setBudgetInput(e.target.value)}
                className="input-field flex-1 h-9 text-lg font-extrabold"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter')
                    onSave({ budget_cents: dollarsToCents(parseInt(budgetInput) || 0) });
                }}
              />
              <button
                onClick={() =>
                  onSave({ budget_cents: dollarsToCents(parseInt(budgetInput) || 0) })
                }
                className="btn btn-primary h-9"
              >
                Save
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {snapPoints.map((amt) => (
                <button
                  key={amt}
                  onClick={() => {
                    setBudgetInput(String(amt));
                    onSave({ budget_cents: dollarsToCents(amt) });
                  }}
                  className={`pill ${
                    project.budget_cents === dollarsToCents(amt)
                      ? 'pill-active'
                      : 'pill-default'
                  }`}
                >
                  {amt === 0 ? 'Rearrange only' : `${amt}`}
                </button>
              ))}
            </div>
            <div className="pt-2 border-t border-cream-200">
              <p className="text-xs font-extrabold uppercase tracking-wider text-plum-light mb-2">
                Budget cap
              </p>
              <div className="flex flex-wrap gap-2">
                {BUDGET_CAPS.map((cap) => (
                  <button
                    key={cap.value}
                    onClick={() => onSave({ budget_cap: cap.value })}
                    className={`pill ${
                      project.budget_cap === cap.value
                        ? 'pill-active'
                        : 'pill-default'
                    }`}
                  >
                    {cap.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {index === 3 && (
          <div className="flex flex-wrap gap-2">
            {MOOD_OPTIONS.map((mood) => (
              <button
                key={mood.name}
                onClick={() =>
                  onSave({
                    mood: mood.name,
                    lighting_recipe: {
                      ambient: mood.a,
                      task: mood.t,
                      accent: mood.x,
                    },
                  })
                }
                className={`pill ${
                  project.mood === mood.name ? 'pill-active' : 'pill-default'
                }`}
              >
                {mood.name}
              </button>
            ))}
          </div>
        )}

        {index === 4 && (
          <div className="flex flex-wrap gap-2">
            {DAMAGE_LEVELS.map((level) => (
              <button
                key={level.value}
                onClick={() => onSave({ damage_level: level.value })}
                className={`pill ${
                  project.damage_level === level.value
                    ? 'pill-active'
                    : 'pill-default'
                }`}
              >
                {level.label}
              </button>
            ))}
          </div>
        )}

        {index === 5 && (
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="4"
              max="50"
              value={wallWidth}
              onChange={(e) => setWallWidth(e.target.value)}
              className="input-field w-24 h-9 text-center"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter')
                  onSave({ wall_width_ft: parseInt(wallWidth) || 12 });
              }}
            />
            <span className="text-sm font-bold text-plum-light">ft</span>
            <button
              onClick={() => onSave({ wall_width_ft: parseInt(wallWidth) || 12 })}
              className="btn btn-primary h-9"
            >
              Save
            </button>
          </div>
        )}
      </div>
    </>
  );
}

function EscapeHandler({ onEscape }: { onEscape: () => void }) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onEscape();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onEscape]);
  return null;
}
