export type BudgetCap = 'hard' | 'soft' | 'none';
export type DamageLevel = 'none' | 'minor' | 'anything';
export type ProjectStatus = 'draft' | 'active' | 'archived';
export type ItemCategory = 'Lighting' | 'Decor' | 'Textiles' | 'Tableware' | 'Furniture';
export type DamageBadge = 'no-damage' | 'minor' | 'needs-ok';
export type ChatRole = 'user' | 'assistant';
export type Effort = 'Light' | 'Medium' | 'Heavy';

export interface LightingRecipe {
  ambient: number;
  task: number;
  accent: number;
}

export interface Project {
  id: string;
  user_id: string;
  title: string;
  room_type: string;
  occasion: string | null;
  budget_cents: number;
  budget_cap: BudgetCap;
  wall_width_ft: number | null;
  wall_width_in: number | null;
  ceiling_height_ft: number | null;
  damage_level: DamageLevel;
  mood: string | null;
  lighting_recipe: LightingRecipe | null;
  constraints: Record<string, unknown> | null;
  status: ProjectStatus;
  photo_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface DesignVersion {
  id: string;
  project_id: string;
  user_id: string;
  version_number: number;
  label: string;
  total_cents: number;
  summary: string;
  room_config: Record<string, unknown>;
  is_current: boolean;
  design_image_url: string | null;
  created_at: string;
}

export interface DesignItem {
  id: string;
  version_id: string;
  user_id: string;
  pin_number: number;
  name: string;
  store: string;
  price_cents: number;
  quantity: number;
  category: ItemCategory;
  damage_badge: DamageBadge;
  wire_color: string | null;
  locked: boolean;
  already_own: boolean;
  notes: string | null;
  sort_order: number;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  project_id: string;
  user_id: string;
  role: ChatRole;
  content: string;
  action_data: Record<string, unknown> | null;
  created_at: string;
}

export interface MoveStep {
  id: string;
  project_id: string;
  user_id: string;
  step_number: number;
  title: string;
  from_location: string;
  to_location: string;
  effort: Effort;
  time_minutes: number;
  tip: string;
  needs_helper: boolean;
  created_at: string;
}

export interface ProjectWithVersions extends Project {
  design_versions?: DesignVersion[];
  current_version?: DesignVersion & { items?: DesignItem[] };
}

export type IntakeStepId =
  | 'photo'
  | 'room-type'
  | 'wall-width'
  | 'ceiling'
  | 'budget'
  | 'cap'
  | 'mood'
  | 'lighting'
  | 'damage'
  | 'review';

export interface IntakeData {
  title: string;
  occasion: string;
  roomType: string;
  wallWidthFt: number;
  wallWidthIn: number;
  ceilingHeightFt: number | null;
  budgetCents: number;
  budgetCap: BudgetCap;
  mood: string;
  damageLevel: DamageLevel;
  lightingRecipe: LightingRecipe;
  photoUploaded: boolean;
  photoFile: File | null;
}

export const MOOD_OPTIONS = [
  { name: 'Cozy', key: 'Warm pools of light', desc: 'Lamps and candles, low overheads', a: 60, t: 20, x: 20 },
  { name: 'Festive', key: 'Sparkle everywhere', desc: 'String lights, color, glow', a: 25, t: 15, x: 60 },
  { name: 'Sleek', key: 'Clean and even', desc: 'Recessed and tracks, minimal warmth', a: 45, t: 40, x: 15 },
  { name: 'Minimalist', key: 'Just what you need', desc: 'Functional lighting, no fuss', a: 50, t: 45, x: 5 },
  { name: 'Romantic', key: 'Soft and dim', desc: 'Candlelight, warm bulbs, shadows', a: 70, t: 10, x: 20 },
  { name: 'Bright', key: 'Daylight indoors', desc: 'High ambient, cool temperature', a: 65, t: 30, x: 5 },
] as const;

export const ROOM_TYPES = ['Living room', 'Studio', 'Bedroom', 'Dining', 'Kitchen', 'Office'];

export const DAMAGE_LEVELS: { value: DamageLevel; label: string; short: string }[] = [
  { value: 'none', label: 'No damage', short: 'No damage' },
  { value: 'minor', label: 'Minor OK (nails, command strips)', short: 'Minor' },
  { value: 'anything', label: 'Anything goes', short: 'Needs OK' },
];

export const BUDGET_CAPS: { value: BudgetCap; label: string; short: string }[] = [
  { value: 'hard', label: 'Hard cap', short: 'Hard cap' },
  { value: 'soft', label: 'Soft cap', short: 'Soft cap' },
  { value: 'none', label: 'No limit', short: 'No limit' },
];
