import { Rocket } from 'lucide-react';

export function Logo({ size = 21, withText = true }: { size?: number; withText?: boolean }) {
  return (
    <span className="flex items-center gap-2">
      <span
        className="flex items-center justify-center rounded-lg bg-sage-300 text-plum"
        style={{ width: size + 6, height: size + 6 }}
        aria-hidden="true"
      >
        <Rocket size={size - 4} strokeWidth={2.5} />
      </span>
      {withText && (
        <span
          className="font-display font-extrabold tracking-tight"
          style={{ fontSize: size, letterSpacing: '-0.02em' }}
        >
          SpaceLift
        </span>
      )}
    </span>
  );
}
