import { useMemo } from 'react';

export interface RoomRenderProps {
  width?: number;
  height?: number;
  evening?: boolean;
  showPins?: boolean;
  selectedPin?: number;
  mood?: string;
  wallWidth?: number;
  className?: string;
  onPinClick?: (pin: number) => void;
}

interface PlacedItem {
  pin: number;
  x: number;
  y: number;
  type: 'sofa' | 'lamp' | 'rug' | 'table' | 'shelf' | 'tv' | 'plant' | 'balloon' | 'lights' | 'lantern' | 'fringe' | 'banner' | 'candle' | 'cushion' | 'throw' | 'vase' | 'mirror';
  label: string;
}

const MOOD_ITEMS: Record<string, PlacedItem[]> = {
  festive: [
    { pin: 1, x: 430, y: 500, type: 'balloon', label: 'Balloon garland' },
    { pin: 2, x: 250, y: 380, type: 'table', label: 'Snack table' },
    { pin: 3, x: 580, y: 300, type: 'lantern', label: 'Paper lanterns' },
    { pin: 4, x: 730, y: 250, type: 'fringe', label: 'Gold fringe' },
    { pin: 5, x: 742, y: 320, type: 'lights', label: 'String lights' },
    { pin: 6, x: 250, y: 370, type: 'rug', label: 'Runner' },
    { pin: 7, x: 400, y: 260, type: 'candle', label: 'Tea lights' },
    { pin: 8, x: 250, y: 360, type: 'shelf', label: 'Cupcake stand' },
    { pin: 9, x: 350, y: 180, type: 'banner', label: 'Tassel banner' },
  ],
  cozy: [
    { pin: 1, x: 250, y: 380, type: 'sofa', label: 'Sofa' },
    { pin: 2, x: 100, y: 340, type: 'lamp', label: 'Floor lamp' },
    { pin: 3, x: 250, y: 300, type: 'cushion', label: 'Cushions' },
    { pin: 4, x: 480, y: 500, type: 'candle', label: 'Candles' },
    { pin: 5, x: 480, y: 490, type: 'rug', label: 'Area rug' },
  ],
  sleek: [
    { pin: 1, x: 730, y: 200, type: 'lights', label: 'Track lights' },
    { pin: 2, x: 742, y: 320, type: 'vase', label: 'Glass vase' },
    { pin: 3, x: 250, y: 290, type: 'cushion', label: 'Velvet pillows' },
    { pin: 4, x: 580, y: 200, type: 'mirror', label: 'Round mirror' },
    { pin: 5, x: 802, y: 280, type: 'lights', label: 'Shelf light' },
    { pin: 6, x: 250, y: 380, type: 'table', label: 'Marble tray' },
  ],
  minimalist: [
    { pin: 1, x: 730, y: 300, type: 'lamp', label: 'Desk lamp' },
    { pin: 2, x: 250, y: 300, type: 'throw', label: 'Cotton throw' },
    { pin: 3, x: 580, y: 260, type: 'plant', label: 'Ceramic planter' },
    { pin: 4, x: 742, y: 380, type: 'shelf', label: 'Woven basket' },
  ],
};

function getMoodKey(mood?: string): string {
  if (!mood) return 'cozy';
  const m = mood.toLowerCase();
  if (m.includes('festive') || m.includes('party')) return 'festive';
  if (m.includes('sleek')) return 'sleek';
  if (m.includes('minimal')) return 'minimalist';
  if (m.includes('romantic')) return 'cozy';
  if (m.includes('bright')) return 'cozy';
  return 'cozy';
}

function renderItem(item: PlacedItem, evening: boolean): JSX.Element {
  const { x, y, type, pin } = item;
  switch (type) {
    case 'sofa':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <ellipse cx="160" cy="52" rx="196" ry="10" fill="#1E1B18" opacity="0.12" />
          <rect x="20" y="0" width="9" height="50" fill="#4A3A2E" />
          <rect x="295" y="0" width="9" height="50" fill="#4A3A2E" />
          <rect x="0" y="-20" width="348" height="24" rx="9" fill="#6F866C" />
          <rect x="16" y="-100" width="316" height="92" rx="22" fill="#7F977C" />
          <rect x="160" y="-90" width="3" height="82" stroke="#6F866C" strokeWidth="3" />
          <rect x="8" y="-30" width="332" height="58" rx="14" fill="#8DA38A" />
        </g>
      );
    case 'lamp':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <ellipse cx="0" cy="52" rx="22" ry="6" fill="#1E1B18" opacity="0.12" />
          <rect x="-2" y="-180" width="4" height="232" fill="#2B2622" />
          <polygon points="-22,-182 22,-182 12,-222 -12,-222" fill={evening ? '#FFE7A8' : '#F4EDE2'} stroke="#DCCFBD" strokeWidth="2" />
          {evening && <circle cx="0" cy="-200" r="30" fill="#FFD98A" opacity="0.3" />}
        </g>
      );
    case 'rug':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <polygon points="-100,30 100,30 140,90 -140,90" fill="#D9A7AF" opacity="0.7" />
          <polygon points="-90,35 90,35 125,85 -125,85" fill="none" stroke="#E8634A" strokeWidth="2" opacity="0.5" />
        </g>
      );
    case 'table':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <ellipse cx="0" cy="12" rx="84" ry="8" fill="#1E1B18" opacity="0.12" />
          <rect x="-54" y="-6" width="8" height="44" fill="#4A3A2E" />
          <rect x="46" y="-6" width="8" height="44" fill="#4A3A2E" />
          <rect x="-66" y="-28" width="132" height="26" rx="9" fill="#B9893A" />
        </g>
      );
    case 'shelf':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <rect x="0" y="0" width="130" height="272" rx="4" fill="#A87B52" />
          <rect x="10" y="10" width="110" height="252" fill="#8F6644" />
          <rect x="10" y="66" width="110" height="8" fill="#A87B52" />
          <rect x="10" y="130" width="110" height="8" fill="#A87B52" />
          <rect x="10" y="192" width="110" height="8" fill="#A87B52" />
        </g>
      );
    case 'tv':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <rect x="0" y="0" width="124" height="94" rx="3" fill="#2B2622" />
          <rect x="8" y="8" width="108" height="78" fill={evening ? '#3A3350' : '#F4EDE2'} />
        </g>
      );
    case 'plant':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <ellipse cx="0" cy="0" rx="22" ry="6" fill="#1E1B18" opacity="0.12" />
          <rect x="-13" y="-24" width="26" height="24" rx="4" fill="#C9694B" />
          <ellipse cx="-6" cy="-36" rx="7" ry="14" fill="#5E7F56" transform="rotate(-25 -6 -36)" />
          <ellipse cx="8" cy="-38" rx="7" ry="15" fill="#6E8F5F" transform="rotate(20 8 -38)" />
          <ellipse cx="1" cy="-44" rx="6" ry="16" fill="#5E7F56" />
        </g>
      );
    case 'balloon':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <ellipse cx="0" cy="0" rx="80" ry="6" fill="#1E1B18" opacity="0.12" />
          <circle cx="-30" cy="-40" r="18" fill="#E3BD55" />
          <circle cx="0" cy="-55" r="16" fill="#F1C3CA" />
          <circle cx="25" cy="-35" r="18" fill="#E3BD55" />
          <circle cx="-15" cy="-25" r="14" fill="#F1C3CA" />
          <circle cx="15" cy="-20" r="14" fill="#E3BD55" />
          <circle cx="0" cy="-35" r="13" fill="#D9A7AF" />
        </g>
      );
    case 'lights':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <rect x="0" y="0" width="4" height="232" fill="#2B2622" />
          <path d="M2 0 Q 20 40 2 80 Q -16 120 2 160 Q 20 200 2 232" stroke={evening ? '#FFD98A' : '#E0A33B'} strokeWidth="2" fill="none" />
          {[-10, 30, 70, 110, 150, 190].map((ly, i) => (
            <circle key={i} cx={i % 2 === 0 ? 18 : -14} cy={ly} r="3" fill={evening ? '#FFE7A8' : '#E0A33B'} opacity={evening ? 1 : 0.7} />
          ))}
        </g>
      );
    case 'lantern':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <line x1="0" y1="-60" x2="0" y2="-20" stroke="#2B2622" strokeWidth="1" />
          <circle cx="0" cy="0" r="16" fill={evening ? '#FFE7A8' : '#F4EDE2'} stroke="#DCCFBD" strokeWidth="2" />
          <line x1="-14" y1="0" x2="14" y2="0" stroke="#DCCFBD" strokeWidth="1" />
          <line x1="0" y1="-14" x2="0" y2="14" stroke="#DCCFBD" strokeWidth="1" />
          {evening && <circle cx="0" cy="0" r="28" fill="#FFD98A" opacity="0.25" />}
        </g>
      );
    case 'fringe':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <rect x="0" y="0" width="80" height="12" fill="#E3BD55" />
          {Array.from({ length: 12 }).map((_, i) => (
            <line key={i} x1={i * 7 + 3} y1="12" x2={i * 7 + 3} y2="40" stroke="#E3BD55" strokeWidth="2" />
          ))}
        </g>
      );
    case 'banner':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <line x1="-60" y1="0" x2="60" y2="0" stroke="#D9A7AF" strokeWidth="2" />
          {Array.from({ length: 7 }).map((_, i) => {
            const tx = -56 + i * 16;
            return <polygon key={i} points={`${tx},0 ${tx + 12},0 ${tx + 6},20`} fill={['#E3BD55', '#F1C3CA', '#D9A7AF'][i % 3]} />;
          })}
        </g>
      );
    case 'candle':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          {[-15, 0, 15].map((cx, i) => (
            <g key={i} transform={`translate(${cx},0)`}>
              <rect x="-3" y="0" width="6" height="14" fill="#EFE9DF" />
              {evening && <circle cx="0" cy="-2" r="2.5" fill="#FFD98A" />}
              {evening && <circle cx="0" cy="-2" r="6" fill="#FFD98A" opacity="0.3" />}
            </g>
          ))}
        </g>
      );
    case 'cushion':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <rect x="-20" y="0" width="40" height="40" rx="8" fill="#D9A7AF" />
          <rect x="10" y="-5" width="40" height="40" rx="8" fill="#E3BD55" />
        </g>
      );
    case 'throw':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <path d="M0 0 Q 30 -10 60 0 L 55 30 Q 30 20 5 28 Z" fill="#C9D8B6" />
        </g>
      );
    case 'vase':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <ellipse cx="0" cy="0" rx="14" ry="4" fill="#1E1B18" opacity="0.1" />
          <path d="M-10 -30 Q -14 -10 -10 0 L 10 0 Q 14 -10 10 -30 Z" fill="#EAF0F4" opacity="0.6" stroke="#BDB6C9" strokeWidth="1" />
        </g>
      );
    case 'mirror':
      return (
        <g key={pin} transform={`translate(${x},${y})`}>
          <circle cx="0" cy="0" r="24" fill="#EAF0F4" stroke="#BDB6C9" strokeWidth="3" />
          <circle cx="-6" cy="-6" r="10" fill="#F5F2E6" opacity="0.4" />
        </g>
      );
    default:
      return <g key={pin} />;
  }
}

export function RoomRender({
  width = 960,
  height = 600,
  evening = false,
  showPins = true,
  selectedPin,
  mood = 'Cozy',
  wallWidth = 12,
  className,
  onPinClick,
}: RoomRenderProps) {
  const moodKey = useMemo(() => getMoodKey(mood), [mood]);
  const items = useMemo(() => MOOD_ITEMS[moodKey] ?? MOOD_ITEMS.cozy, [moodKey]);
  const uid = useMemo(() => `r${Math.random().toString(36).slice(2, 8)}`, []);

  return (
    <svg
      viewBox="0 0 960 600"
      className={className}
      style={{ display: 'block', width: '100%', height: 'auto', maxWidth: `${width}px`, maxHeight: `${height}px` }}
      role="img"
      aria-label={`${mood} room design, ${evening ? 'evening view' : 'day view'}, ${wallWidth} foot wall`}
    >
      <defs>
        <radialGradient id={`gw-${uid}`}>
          <stop offset="0" stopColor="#FFD98A" stopOpacity={evening ? '0.95' : '0'} />
          <stop offset="1" stopColor="#FFB547" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`gc-${uid}`}>
          <stop offset="0" stopColor="#F2F6FF" stopOpacity="0.9" />
          <stop offset="1" stopColor="#DCE6FF" stopOpacity="0" />
        </radialGradient>
        <pattern id={`fr-${uid}`} x="0" y="0" width="8" height="10" patternUnits="userSpaceOnUse">
          <rect x="0" y="0" width="4" height="10" fill="#E3BD55" />
          <rect x="4" y="0" width="4" height="10" fill="#F1C3CA" />
        </pattern>
      </defs>

      {/* Wall */}
      <rect x="0" y="0" width="960" height="420" fill={evening ? '#2B2735' : '#EDE3D4'} />
      {/* Wall shadow */}
      <rect x="0" y="0" width="960" height="16" fill="#1E1B18" opacity="0.05" />

      {/* Window */}
      <rect x="124" y="64" width="192" height="212" rx="6" fill={evening ? '#1C1924' : '#FBF7F0'} />
      <rect x="136" y="76" width="80" height="188" fill={evening ? '#25212E' : '#CFE3EC'} />
      <rect x="224" y="76" width="80" height="188" fill={evening ? '#25212E' : '#CFE3EC'} />
      <path d="M136 230Q176 200 216 222V264H136Z" fill={evening ? '#2F3A28' : '#B5D2BE'} />
      <path d="M224 226Q268 196 304 218V264H224Z" fill={evening ? '#2F3A28' : '#B5D2BE'} />
      <rect x="116" y="272" width="208" height="10" rx="3" fill={evening ? '#332D40' : '#F6EEE2'} />

      {/* Floor */}
      <rect x="0" y="420" width="960" height="180" fill={evening ? '#3A2A10' : '#C8976A'} />
      {/* Floor planks */}
      <path
        d="M0 462H960M0 510H960M0 560H960M140 420V462M520 420V462M860 420V462M60 462V510M400 462V510M760 462V510M240 510V560M620 510V560M100 560V600M480 560V600M880 560V600"
        stroke={evening ? '#2A1F0F' : '#B5845A'}
        strokeWidth="2"
        fill="none"
      />
      {/* Baseboard */}
      <rect x="0" y="410" width="960" height="12" fill={evening ? '#25212E' : '#F6EEE2'} />

      {/* Evening light glows */}
      {evening && (
        <>
          <ellipse cx="742" cy="200" rx="120" ry="80" fill={`url(#gw-${uid})`} />
          <ellipse cx="100" cy="250" rx="100" ry="70" fill={`url(#gw-${uid})`} opacity="0.7" />
          <rect x="0" y="0" width="960" height="420" fill="#2B2735" opacity="0.3" />
        </>
      )}

      {/* Items */}
      {items.map((item) => renderItem(item, evening))}

      {/* Pins */}
      {showPins &&
        items.map((item) => {
          const isSelected = selectedPin === item.pin;
          return (
            <g
              key={`pin-${item.pin}`}
              transform={`translate(${item.x + 25},${item.y - 110})`}
              onClick={() => onPinClick?.(item.pin)}
              role="button"
              aria-label={`Pin ${item.pin}: ${item.label}`}
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onPinClick?.(item.pin);
                }
              }}
              style={{ cursor: onPinClick ? 'pointer' : 'default' }}
            >
              <circle
                cx="0"
                cy="0"
                r={isSelected ? 16 : 13}
                fill={isSelected ? '#E09A1F' : '#2B2735'}
                stroke="#F5F2E6"
                strokeWidth="2.5"
                className={isSelected ? 'animate-glow-pulse' : ''}
              />
              <text
                x="0"
                y="4"
                textAnchor="middle"
                fontSize="13"
                fontWeight="800"
                fill="#F5F2E6"
                fontFamily="Figtree, sans-serif"
                pointerEvents="none"
              >
                {item.pin}
              </text>
            </g>
          );
        })}

      {/* Day/evening overlay */}
      {evening && (
        <polygon points="136,420 304,420 430,600 170,600" fill="#FFFFFF" opacity="0.05" />
      )}
    </svg>
  );
}
