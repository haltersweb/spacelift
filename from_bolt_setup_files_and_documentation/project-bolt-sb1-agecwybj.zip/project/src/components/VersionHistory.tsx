import { useState } from 'react';
import { History, RotateCcw, Eye, ArrowLeftRight, Check } from 'lucide-react';
import type { DesignVersion } from '@/types';
import { formatCurrency, formatDate } from '@/lib/format';

interface VersionHistoryProps {
  versions: DesignVersion[];
  currentVersionId: string | null;
  onRestore: (versionId: string) => void;
  onCompare: (versionId: string) => void;
  onClose: () => void;
}

export function VersionHistory({
  versions,
  currentVersionId,
  onRestore,
  onCompare,
  onClose,
}: VersionHistoryProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <div className="flex flex-col h-full bg-cream-50">
      <div className="flex items-center justify-between p-3 border-b border-cream-300">
        <div className="flex items-center gap-2">
          <History size={16} className="text-plum-light" aria-hidden="true" />
          <h2 className="font-bold text-sm">Versions</h2>
        </div>
        <button
          onClick={onClose}
          className="text-xs text-plum-light hover:text-plum font-bold"
        >
          Close
        </button>
      </div>

      <p className="text-xs text-plum-light px-3 py-2 border-b border-cream-300">
        Click to view · tab to a version for Restore / Compare
      </p>

      <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
        {versions.map((version, idx) => {
          const isCurrent = version.id === currentVersionId;
          return (
            <div
              key={version.id}
              className={`group p-3 rounded-xl border cursor-pointer transition-all ${
                isCurrent
                  ? 'border-sage-400 bg-sage-200'
                  : 'border-cream-300 bg-cream-50 hover:border-lavender-300'
              }`}
              onClick={() => !isCurrent && onCompare(version.id)}
              onMouseEnter={() => setHoveredId(version.id)}
              onMouseLeave={() => setHoveredId(null)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if ((e.key === 'Enter' || e.key === ' ') && !isCurrent) {
                  e.preventDefault();
                  onCompare(version.id);
                }
              }}
              onFocus={() => setHoveredId(version.id)}
              aria-label={`Version ${version.version_number}: ${version.label}, ${formatCurrency(version.total_cents)}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-extrabold ${
                      isCurrent
                        ? 'bg-sage-400 text-cream-50'
                        : 'bg-lavender-200 text-plum'
                    }`}
                  >
                    {isCurrent ? (
                      <Check size={12} aria-hidden="true" />
                    ) : (
                      version.version_number
                    )}
                  </span>
                  <div>
                    <p className="text-sm font-bold text-plum">
                      {version.label}
                    </p>
                    <p className="text-xs text-plum-light">
                      {formatCurrency(version.total_cents)} · {formatDate(version.created_at)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Hover actions */}
              {hoveredId === version.id && !isCurrent && (
                <div className="flex gap-2 mt-2 animate-slide-up">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRestore(version.id);
                    }}
                    className="btn btn-ghost text-2xs h-7 px-2 text-plum-light hover:text-plum"
                  >
                    <RotateCcw size={11} aria-hidden="true" />
                    Restore
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCompare(version.id);
                    }}
                    className="btn btn-ghost text-2xs h-7 px-2 text-plum-light hover:text-plum"
                  >
                    <ArrowLeftRight size={11} aria-hidden="true" />
                    Compare
                  </button>
                </div>
              )}

              {isCurrent && (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-sage-700 mt-1">
                  <Eye size={11} aria-hidden="true" />
                  Viewing
                </span>
              )}
            </div>
          );
        })}
        {versions.length === 0 && (
          <div className="text-center py-8 text-plum-light">
            <History size={24} className="mx-auto mb-2 opacity-40" aria-hidden="true" />
            <p className="text-sm">No versions yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
