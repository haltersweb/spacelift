import { useState } from 'react';
import {
  Lock,
  Unlock,
  Trash2,
  ShoppingCart,
  Search,
  Check,
  AlertTriangle,
  X,
} from 'lucide-react';
import type { DesignItem, ItemCategory, DamageBadge } from '@/types';
import { formatCurrency } from '@/lib/format';
import { getSwapSuggestions, type SwapSuggestion } from '@/lib/design';

interface ShoppingListProps {
  items: DesignItem[];
  budgetCents: number;
  totalCents: number;
  onLock: (id: string) => void;
  onRemove: (id: string) => void;
  onOwn: (id: string) => void;
  onSwap: (id: string, suggestion: SwapSuggestion) => void;
  onQtyChange: (id: string, qty: number) => void;
}

const CATEGORY_COLORS: Record<ItemCategory, string> = {
  Lighting: 'bg-accent-warm/20 text-accent-warm',
  Decor: 'bg-accent-coral/20 text-accent-coral',
  Textiles: 'bg-sage-300/40 text-sage-700',
  Tableware: 'bg-lavender-200 text-plum',
  Furniture: 'bg-info-light text-info',
};

const DAMAGE_LABELS: Record<DamageBadge, { label: string; icon: string; color: string }> = {
  'no-damage': { label: 'No damage', icon: '✓', color: 'text-success' },
  'minor': { label: 'Minor', icon: '○', color: 'text-warning' },
  'needs-ok': { label: 'Needs OK', icon: '!', color: 'text-error' },
};

export function ShoppingList({
  items,
  budgetCents,
  totalCents,
  onLock,
  onRemove,
  onOwn,
  onSwap,
  onQtyChange,
}: ShoppingListProps) {
  const [filter, setFilter] = useState<'all' | 'no-damage' | 'minor' | 'needs-ok'>('all');
  const [swapItem, setSwapItem] = useState<DesignItem | null>(null);

  const filtered = filter === 'all' ? items : items.filter((i) => i.damage_badge === filter);
  const allSafe = items.every((i) => i.damage_badge === 'no-damage');
  const overBudget = totalCents > budgetCents && budgetCents > 0;

  return (
    <div className="flex flex-col h-full">
      {/* Summary bar */}
      <div className="flex items-center justify-between p-4 border-b border-cream-300">
        <div className="flex items-center gap-3">
          <span className="font-bold text-sm">{items.length} items</span>
          {allSafe ? (
            <span className="inline-flex items-center gap-1 text-xs font-bold text-success">
              <Check size={13} aria-hidden="true" />
              All lease-safe
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-xs font-bold text-warning">
              <AlertTriangle size={13} aria-hidden="true" />
              Some items need OK
            </span>
          )}
        </div>
        <div className="flex gap-1.5">
          {(['all', 'no-damage', 'minor', 'needs-ok'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`pill text-2xs h-7 px-2.5 ${
                filter === f ? 'pill-active' : 'pill-default'
              }`}
            >
              {f === 'all' ? 'All' : DAMAGE_LABELS[f as DamageBadge].label}
            </button>
          ))}
        </div>
      </div>

      {/* Over budget banner */}
      {overBudget && (
        <div className="bg-warning-light border-b border-warning/20 p-4">
          <p className="text-sm font-bold text-plum">
            You're {formatCurrency(totalCents - budgetCents)} over. Fit to budget?
          </p>
          <p className="text-xs text-plum-light mt-1">
            I can suggest two cheaper swaps to get you under {formatCurrency(budgetCents)}.
          </p>
          <button className="btn btn-sage text-xs mt-2 h-8">
            <Search size={13} aria-hidden="true" />
            Find cheaper swaps
          </button>
        </div>
      )}

      {/* Items list */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filtered.map((item) => (
          <ItemCard
            key={item.id}
            item={item}
            onLock={() => onLock(item.id)}
            onRemove={() => onRemove(item.id)}
            onOwn={() => onOwn(item.id)}
            onSwapClick={() => setSwapItem(item)}
            onQtyChange={(qty) => onQtyChange(item.id, qty)}
          />
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-12 text-plum-light">
            <ShoppingCart size={32} className="mx-auto mb-3 opacity-40" aria-hidden="true" />
            <p className="font-medium">No items match this filter</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-cream-300 p-4 bg-cream-50">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-bold text-plum-light">Subtotal</span>
          <span className="font-display font-extrabold text-lg">
            {formatCurrency(totalCents)}
          </span>
        </div>
        <p className="text-xs text-plum-light mb-3">
          Prices are estimates. Tap Buy for the current price. Tax and shipping
          not included.
        </p>
        <div className="flex gap-2">
          <button className="btn btn-secondary text-xs flex-1 h-9">
            Copy list
          </button>
          <button className="btn btn-secondary text-xs flex-1 h-9">
            Checklist PDF
          </button>
          <button className="btn btn-secondary text-xs flex-1 h-9">
            Share
          </button>
        </div>
      </div>

      {/* Swap drawer */}
      {swapItem && (
        <SwapDrawer
          item={swapItem}
          onClose={() => setSwapItem(null)}
          onSelect={(suggestion) => {
            onSwap(swapItem.id, suggestion);
            setSwapItem(null);
          }}
        />
      )}
    </div>
  );
}

function ItemCard({
  item,
  onLock,
  onRemove,
  onOwn,
  onSwapClick,
  onQtyChange,
}: {
  item: DesignItem;
  onLock: () => void;
  onRemove: () => void;
  onOwn: () => void;
  onSwapClick: () => void;
  onQtyChange: (qty: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const damage = DAMAGE_LABELS[item.damage_badge];

  return (
    <div
      className={`card p-3 transition-all ${item.locked ? 'ring-1 ring-sage-400/40' : ''} ${
        item.already_own ? 'opacity-60' : ''
      }`}
    >
      <div className="flex items-start gap-3">
        {/* Pin number */}
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-plum text-cream-50 flex items-center justify-center text-sm font-extrabold">
          {item.pin_number}
        </div>

        {/* Item info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="font-bold text-sm text-plum truncate">
                {item.name}
              </p>
              <p className="text-xs text-plum-light">
                {item.store} · {item.wire_color ? `${item.wire_color} wire · ` : ''}
                {formatCurrency(item.price_cents)}
              </p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <span className={`text-2xs px-1.5 py-0.5 rounded-full font-bold ${damage.color}`}>
                {damage.label}
              </span>
            </div>
          </div>

          {/* Category + badges */}
          <div className="flex items-center gap-2 mt-2">
            <span
              className={`text-2xs px-2 py-0.5 rounded-full font-bold ${CATEGORY_COLORS[item.category]}`}
            >
              {item.category}
            </span>
            {item.already_own && (
              <span className="text-2xs font-bold text-sage-700 inline-flex items-center gap-0.5">
                <Check size={11} aria-hidden="true" /> Own it
              </span>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 mt-2.5">
            <button
              onClick={onSwapClick}
              className="btn btn-ghost text-2xs h-7 px-2 text-plum-light hover:text-plum"
            >
              <Search size={12} aria-hidden="true" />
              Swap
            </button>
            <button
              onClick={onLock}
              className="btn btn-ghost text-2xs h-7 px-2 text-plum-light hover:text-plum"
              aria-label={item.locked ? 'Unlock item' : 'Lock item'}
            >
              {item.locked ? (
                <Lock size={12} aria-hidden="true" />
              ) : (
                <Unlock size={12} aria-hidden="true" />
              )}
              {item.locked ? 'Locked' : 'Lock'}
            </button>
            <button
              onClick={onOwn}
              className="btn btn-ghost text-2xs h-7 px-2 text-plum-light hover:text-plum"
            >
              I have this
            </button>
            <button
              onClick={() => setExpanded(!expanded)}
              className="btn btn-ghost text-2xs h-7 px-2 text-plum-light hover:text-plum"
              aria-expanded={expanded}
            >
              {expanded ? 'Less' : 'More'}
            </button>
          </div>

          {/* Expanded */}
          {expanded && (
            <div className="mt-3 pt-3 border-t border-cream-300 space-y-3 animate-slide-up">
              {/* Quantity */}
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-plum-light">Quantity</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onQtyChange(Math.max(1, item.quantity - 1))}
                    className="w-7 h-7 rounded-lg border border-cream-300 flex items-center justify-center text-sm font-bold hover:bg-lavender-100"
                    aria-label="Decrease quantity"
                  >
                    −
                  </button>
                  <span className="font-bold text-sm w-6 text-center">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => onQtyChange(item.quantity + 1)}
                    className="w-7 h-7 rounded-lg border border-cream-300 flex items-center justify-center text-sm font-bold hover:bg-lavender-100"
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
                <span className="text-xs font-bold text-plum ml-auto">
                  {formatCurrency(item.price_cents * item.quantity)} est.
                </span>
              </div>

              {/* Buy link */}
              <button className="btn btn-secondary w-full text-xs h-8">
                Buy at {item.store}
              </button>

              {/* Remove */}
              <button
                onClick={onRemove}
                className="btn btn-ghost w-full text-xs h-8 text-error hover:bg-error-light"
              >
                <Trash2 size={13} aria-hidden="true" />
                Remove from list
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SwapDrawer({
  item,
  onClose,
  onSelect,
}: {
  item: DesignItem;
  onClose: () => void;
  onSelect: (s: SwapSuggestion) => void;
}) {
  const suggestions = getSwapSuggestions(item);
  const [previewing, setPreviewing] = useState<SwapSuggestion | null>(null);

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end animate-fade-in"
      onKeyDown={(e) => {
        if (e.key === 'Escape') onClose();
      }}
    >
      <div
        className="absolute inset-0 bg-plum/40"
        onClick={onClose}
        aria-label="Close swap drawer"
        role="button"
        tabIndex={-1}
      />
      <div
        className="relative w-full max-w-md bg-cream-50 shadow-elevated flex flex-col animate-slide-right"
        role="dialog"
        aria-modal="true"
        aria-labelledby="swap-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-cream-300">
          <div>
            <h2 id="swap-title" className="font-display font-bold text-lg">
              Swap pin {item.pin_number}
            </h2>
            <p className="text-xs text-plum-light">{item.name}</p>
          </div>
          <button
            onClick={onClose}
            className="btn btn-ghost h-8 w-8 p-0"
            aria-label="Close swap drawer"
          >
            <X size={18} aria-hidden="true" />
          </button>
        </div>

        {/* Current */}
        <div className="p-4 border-b border-cream-300">
          <p className="text-xs font-bold uppercase tracking-wider text-plum-light mb-1">
            Current
          </p>
          <p className="text-sm font-bold text-plum">
            {item.store} · {formatCurrency(item.price_cents)}
            {item.wire_color && ` · ${item.wire_color} wire`}
          </p>
        </div>

        {/* Suggestions */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <p className="text-xs font-bold uppercase tracking-wider text-plum-light">
            Alternatives
          </p>
          {suggestions.map((s, i) => (
            <div
              key={i}
              className={`card p-3 cursor-pointer transition-all ${
                previewing?.name === s.name
                  ? 'ring-2 ring-sage-400'
                  : 'hover:shadow-soft'
              }`}
              onClick={() => setPreviewing(s)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setPreviewing(s);
                }
              }}
              role="button"
              tabIndex={0}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-bold text-sm">{s.name}</p>
                  <p className="text-xs text-plum-light">{s.store}</p>
                  {s.wireColor && (
                    <p className="text-xs text-plum-light">{s.wireColor} wire</p>
                  )}
                </div>
                <div className="text-right">
                  <p className="font-bold text-sm">{formatCurrency(s.priceCents)}</p>
                  <p
                    className={`text-xs font-bold ${
                      s.diff < 0 ? 'text-success' : s.diff > 0 ? 'text-error' : 'text-plum-light'
                    }`}
                  >
                    {s.diff < 0 ? '−' : s.diff > 0 ? '+' : ''}
                    {formatCurrency(Math.abs(s.diff))}
                  </p>
                </div>
              </div>
              <p className="text-xs text-plum-light mt-2">{s.reason}</p>
              {previewing?.name === s.name && (
                <div className="mt-3 flex gap-2 animate-slide-up">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setPreviewing(null);
                    }}
                    className="btn btn-ghost text-xs flex-1 h-8"
                  >
                    Stop preview
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelect(s);
                    }}
                    className="btn btn-sage text-xs flex-1 h-8"
                  >
                    Use this
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
