import { useState, useEffect, useRef, type FormEvent } from 'react';
import { Send, MessageSquare, Sparkles, RotateCcw } from 'lucide-react';
import type { ChatMessage } from '@/types';
import { formatTime } from '@/lib/format';

interface ChatPanelProps {
  messages: ChatMessage[];
  projectName: string;
  budgetCents: number;
  totalCents: number;
  onSend: (content: string) => void;
  isTyping: boolean;
}

const QUICK_PROMPTS = [
  'Can the string lights be black wire?',
  'Can the paper lanterns light up?',
  'Make it more festive',
  "What will it look like at night?",
];

export function ChatPanel({
  messages,
  projectName,
  budgetCents,
  totalCents,
  onSend,
  isTyping,
}: ChatPanelProps) {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: 'smooth',
    });
  }, [messages, isTyping]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setInput('');
  };

  const context = { projectName, budgetCents, totalCents };
  void context;

  return (
    <div className="flex flex-col h-full bg-cream-50">
      {/* Header */}
      <div className="flex items-center gap-2 p-3 border-b border-cream-300">
        <div className="w-8 h-8 rounded-lg bg-sage-300 flex items-center justify-center flex-shrink-0">
          <Sparkles size={16} className="text-plum" aria-hidden="true" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-sm text-plum">Message SpaceLift</p>
          <p className="text-xs text-plum-light">Ask for swaps, changes, or ideas</p>
        </div>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 space-y-3"
        role="log"
        aria-live="polite"
        aria-label="Chat messages"
      >
        {messages.length === 0 && (
          <div className="text-center py-8">
            <MessageSquare
              size={28}
              className="mx-auto mb-3 text-plum-light opacity-40"
              aria-hidden="true"
            />
            <p className="text-sm font-medium text-plum-light">
              Ask me anything about your design
            </p>
            <p className="text-xs text-plum-light mt-1">
              I can swap items, change colors, or suggest alternatives
            </p>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 ${
                msg.role === 'user'
                  ? 'bg-plum text-cream-50 rounded-br-md'
                  : 'bg-lavender-100 text-plum rounded-bl-md'
              }`}
            >
              <p className="text-sm leading-relaxed">{msg.content}</p>
              <p
                className={`text-2xs mt-1 ${
                  msg.role === 'user' ? 'text-cream-50/60' : 'text-plum-light'
                }`}
              >
                {formatTime(msg.created_at)}
              </p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start animate-fade-in">
            <div className="bg-lavender-100 rounded-2xl rounded-bl-md px-4 py-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 rounded-full bg-plum-light animate-pulse-soft" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 rounded-full bg-plum-light animate-pulse-soft" style={{ animationDelay: '200ms' }} />
                <span className="w-2 h-2 rounded-full bg-plum-light animate-pulse-soft" style={{ animationDelay: '400ms' }} />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick prompts */}
      {messages.length === 0 && (
        <div className="px-3 pb-2 flex flex-wrap gap-1.5">
          {QUICK_PROMPTS.map((prompt) => (
            <button
              key={prompt}
              onClick={() => onSend(prompt)}
              className="pill pill-default text-2xs"
            >
              {prompt}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-2 p-3 border-t border-cream-300"
      >
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="input-field flex-1 h-10 text-sm"
          placeholder="Point to it or ask..."
          aria-label="Type a message to SpaceLift"
          disabled={isTyping}
        />
        <button
          type="submit"
          className="btn btn-primary h-10 w-10 p-0 flex-shrink-0"
          disabled={!input.trim() || isTyping}
          aria-label="Send message"
        >
          <Send size={16} aria-hidden="true" />
        </button>
      </form>

      {/* Stop button */}
      {isTyping && (
        <div className="px-3 pb-3">
          <button className="btn btn-ghost w-full text-xs text-plum-light h-8">
            <RotateCcw size={12} aria-hidden="true" />
            Stop
          </button>
        </div>
      )}
    </div>
  );
}
