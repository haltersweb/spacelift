import { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { LandingPage } from '@/pages/LandingPage';
import { AuthPage } from '@/pages/AuthPage';
import { IntakePage } from '@/pages/IntakePage';
import { Workspace } from '@/pages/Workspace';
import { ComparePage } from '@/pages/ComparePage';
import { Dashboard } from '@/pages/Dashboard';
import { createProject, createVersion, fetchVersions, insertItems, updateProject } from '@/lib/api';
import { generateDesign } from '@/lib/design';
import type { IntakeData } from '@/types';

type Route =
  | { name: 'landing' }
  | { name: 'auth'; mode: 'signin' | 'signup' }
  | { name: 'dashboard' }
  | { name: 'intake' }
  | { name: 'workspace'; projectId: string }
  | { name: 'compare' };

function AppContent() {
  const { session, loading, signOut } = useAuth();
  const [route, setRoute] = useState<Route>({ name: 'landing' });
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');

  // Redirect based on auth state
  useEffect(() => {
    if (loading) return;
    if (session && route.name === 'landing') {
      setRoute({ name: 'dashboard' });
    }
    if (session && route.name === 'auth') {
      setRoute({ name: 'dashboard' });
    }
    if (!session && (route.name === 'dashboard' || route.name === 'workspace' || route.name === 'compare')) {
      setRoute({ name: 'landing' });
    }
  }, [session, loading, route]);

  const handleStart = useCallback(() => {
    if (session) {
      setRoute({ name: 'intake' });
    } else {
      setAuthMode('signup');
      setRoute({ name: 'auth', mode: 'signup' });
    }
  }, [session]);

  const handleSignIn = useCallback(() => {
    setAuthMode('signin');
    setRoute({ name: 'auth', mode: 'signin' });
  }, []);

  const handleAuthSuccess = useCallback(() => {
    setRoute({ name: 'dashboard' });
  }, []);

  const handleToggleAuth = useCallback(() => {
    setAuthMode((prev) => (prev === 'signin' ? 'signup' : 'signin'));
    setRoute({ name: 'auth', mode: authMode === 'signin' ? 'signup' : 'signin' });
  }, [authMode]);

  const handleIntakeComplete = useCallback(
    async (data: IntakeData, uploadPhoto?: (file: File) => Promise<string | null>) => {
      try {
        // Upload photo if one was selected
        let photoUrl: string | null = null;
        if (data.photoFile && uploadPhoto) {
          photoUrl = await uploadPhoto(data.photoFile);
        }

        const project = await createProject({
          title: data.title || `${data.roomType} · ${data.occasion}`,
          room_type: data.roomType,
          occasion: data.occasion,
          budget_cents: data.budgetCents,
          budget_cap: data.budgetCap,
          wall_width_ft: data.wallWidthFt,
          wall_width_in: data.wallWidthIn,
          ceiling_height_ft: data.ceilingHeightFt,
          damage_level: data.damageLevel,
          mood: data.mood,
          lighting_recipe: data.lightingRecipe,
          status: 'active',
        });

        // Save photo URL to project if uploaded
        if (photoUrl) {
          await updateProject(project.id, { photo_url: photoUrl });
        }

        // Generate initial design version
        const design = generateDesign(data, true);
        await createVersion(project.id, {
          version_number: 1,
          label: design.label,
          total_cents: design.totalCents,
          summary: design.summary,
          room_config: design.roomConfig,
          is_current: true,
        });

        // Insert items
        const currentVersions = await fetchVersions(project.id);
        const versionId = currentVersions[0]?.id;
        if (versionId) {
          await insertItems(versionId, design.items);
        }

        setRoute({ name: 'workspace', projectId: project.id });
      } catch (err) {
        console.error('Failed to create project:', err);
        setRoute({ name: 'dashboard' });
      }
    },
    []
  );

  const handleSignOut = useCallback(async () => {
    await signOut();
    setRoute({ name: 'landing' });
  }, [signOut]);

  if (loading) {
    return (
      <div className="min-h-screen bg-cream-100 flex items-center justify-center">
        <div className="w-12 h-12 rounded-full border-4 border-cream-300 border-t-sage-400 animate-spin" />
      </div>
    );
  }

  switch (route.name) {
    case 'landing':
      return <LandingPage onStart={handleStart} onSignIn={handleSignIn} />;

    case 'auth':
      return (
        <AuthPage
          mode={route.mode}
          onBack={() => setRoute({ name: 'landing' })}
          onSuccess={handleAuthSuccess}
          onToggleMode={handleToggleAuth}
        />
      );

    case 'dashboard':
      return (
        <Dashboard
          onNewProject={() => setRoute({ name: 'intake' })}
          onOpenProject={(id) => setRoute({ name: 'workspace', projectId: id })}
          onCompare={() => setRoute({ name: 'compare' })}
          onSignOut={handleSignOut}
        />
      );

    case 'intake':
      return (
        <IntakePage
          onComplete={handleIntakeComplete}
          onBack={() => setRoute({ name: 'dashboard' })}
        />
      );

    case 'workspace':
      return (
        <Workspace
          projectId={route.projectId}
          onBack={() => setRoute({ name: 'dashboard' })}
          onCompare={(id) => setRoute({ name: 'compare' })}
        />
      );

    case 'compare':
      return (
        <ComparePage
          onBack={() => setRoute({ name: 'dashboard' })}
          onSignOut={handleSignOut}
        />
      );

    default:
      return <LandingPage onStart={handleStart} onSignIn={handleSignIn} />;
  }
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
